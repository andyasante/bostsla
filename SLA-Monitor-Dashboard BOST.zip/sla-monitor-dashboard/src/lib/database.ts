import { Pool } from 'pg';
import mysql from 'mysql2/promise';
import { MongoClient } from 'mongodb';

export interface DatabaseConfig {
  type: 'postgresql' | 'mysql' | 'mongodb' | 'sqlserver';
  host: string;
  port: number;
  database: string;
  username: string;
  password: string;
  ssl?: boolean;
}

// Define proper types for database query results
export type DatabaseQueryResult = Record<string, unknown>[];
export type DatabaseQueryParams = (string | number | boolean | null | undefined)[];

export interface DatabaseConnection {
  query: (sql: string, params?: DatabaseQueryParams) => Promise<DatabaseQueryResult>;
  close: () => Promise<void>;
  isConnected: () => boolean;
}

class PostgreSQLConnection implements DatabaseConnection {
  private pool: Pool;
  private connected = false;

  constructor(config: DatabaseConfig) {
    this.pool = new Pool({
      host: config.host,
      port: config.port,
      database: config.database,
      user: config.username,
      password: config.password,
      ssl: config.ssl ? { rejectUnauthorized: false } : false,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });
    this.connected = true;
  }

  async query(sql: string, params?: DatabaseQueryParams): Promise<DatabaseQueryResult> {
    try {
      const result = await this.pool.query(sql, params);
      return result.rows as DatabaseQueryResult;
    } catch (error) {
      console.error('PostgreSQL Query Error:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    await this.pool.end();
    this.connected = false;
  }

  isConnected(): boolean {
    return this.connected;
  }
}

class MySQLConnection implements DatabaseConnection {
  private connection: mysql.Connection | null = null;
  private connected = false;

  constructor(private config: DatabaseConfig) {}

  async connect(): Promise<void> {
    this.connection = await mysql.createConnection({
      host: this.config.host,
      port: this.config.port,
      database: this.config.database,
      user: this.config.username,
      password: this.config.password,
      ssl: this.config.ssl ? {} : false,
    });
    this.connected = true;
  }

  async query(sql: string, params?: DatabaseQueryParams): Promise<DatabaseQueryResult> {
    if (!this.connection) {
      await this.connect();
    }
    try {
      const [rows] = await this.connection?.execute(sql, params) || [[]];
      return rows as DatabaseQueryResult;
    } catch (error) {
      console.error('MySQL Query Error:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.connection) {
      await this.connection.end();
      this.connected = false;
    }
  }

  isConnected(): boolean {
    return this.connected;
  }
}

export class DatabaseManager {
  private static instance: DatabaseManager;
  private connections: Map<string, DatabaseConnection> = new Map();

  static getInstance(): DatabaseManager {
    if (!DatabaseManager.instance) {
      DatabaseManager.instance = new DatabaseManager();
    }
    return DatabaseManager.instance;
  }

  async createConnection(id: string, config: DatabaseConfig): Promise<DatabaseConnection> {
    let connection: DatabaseConnection;

    switch (config.type) {
      case 'postgresql':
        connection = new PostgreSQLConnection(config);
        break;
      case 'mysql': {
        const mysqlConn = new MySQLConnection(config);
        await mysqlConn.connect();
        connection = mysqlConn;
        break;
      }
      default:
        throw new Error(`Unsupported database type: ${config.type}`);
    }

    this.connections.set(id, connection);
    return connection;
  }

  getConnection(id: string): DatabaseConnection | null {
    return this.connections.get(id) || null;
  }

  async testConnection(config: DatabaseConfig): Promise<{ success: boolean; message: string }> {
    try {
      const testId = `test-${Date.now()}`;
      const connection = await this.createConnection(testId, config);

      // Test with a simple query
      await connection.query('SELECT 1 as test');
      await connection.close();
      this.connections.delete(testId);

      return {
        success: true,
        message: `Successfully connected to ${config.type} database at ${config.host}:${config.port}`
      };
    } catch (error) {
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Connection failed'
      };
    }
  }

  async closeConnection(id: string): Promise<void> {
    const connection = this.connections.get(id);
    if (connection) {
      await connection.close();
      this.connections.delete(id);
    }
  }

  async closeAllConnections(): Promise<void> {
    for (const [id, connection] of this.connections) {
      await connection.close();
    }
    this.connections.clear();
  }
}

// Database initialization and schema creation
export async function initializeDatabase(connection: DatabaseConnection): Promise<void> {
  const tables = [
    `CREATE TABLE IF NOT EXISTS services (
      id SERIAL PRIMARY KEY,
      service_id VARCHAR(50) UNIQUE NOT NULL,
      name VARCHAR(255) NOT NULL,
      department VARCHAR(100),
      endpoint VARCHAR(500),
      status VARCHAR(50) DEFAULT 'operational',
      uptime DECIMAL(5,2) DEFAULT 100.00,
      response_time VARCHAR(20) DEFAULT 'N/A',
      sla_compliance DECIMAL(5,2) DEFAULT 99.00,
      sla_target DECIMAL(5,2) DEFAULT 99.00,
      response_time_target INTEGER DEFAULT 3,
      priority VARCHAR(20) DEFAULT 'medium',
      monitoring_enabled BOOLEAN DEFAULT true,
      last_incident VARCHAR(100) DEFAULT 'Never',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,

    `CREATE TABLE IF NOT EXISTS incidents (
      id SERIAL PRIMARY KEY,
      incident_id VARCHAR(50) UNIQUE NOT NULL,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      severity VARCHAR(20) NOT NULL,
      department VARCHAR(100),
      status VARCHAR(50) DEFAULT 'open',
      assignee VARCHAR(100),
      affected_services TEXT[],
      estimated_resolution VARCHAR(100),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      resolved_at TIMESTAMP NULL
    )`,

    `CREATE TABLE IF NOT EXISTS alerts (
      id SERIAL PRIMARY KEY,
      alert_id VARCHAR(50) UNIQUE NOT NULL,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      severity VARCHAR(20) NOT NULL,
      department VARCHAR(100),
      status VARCHAR(50) DEFAULT 'active',
      service_id VARCHAR(50),
      assignee VARCHAR(100),
      affected_services TEXT[],
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      acknowledged_at TIMESTAMP NULL,
      resolved_at TIMESTAMP NULL
    )`,

    `CREATE TABLE IF NOT EXISTS metrics (
      id SERIAL PRIMARY KEY,
      service_id VARCHAR(50) NOT NULL,
      metric_type VARCHAR(50) NOT NULL,
      value DECIMAL(10,2) NOT NULL,
      unit VARCHAR(20),
      timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (service_id) REFERENCES services(service_id)
    )`,

    `CREATE TABLE IF NOT EXISTS database_connections (
      id SERIAL PRIMARY KEY,
      connection_id VARCHAR(50) UNIQUE NOT NULL,
      name VARCHAR(255) NOT NULL,
      type VARCHAR(50) NOT NULL,
      host VARCHAR(255) NOT NULL,
      port INTEGER NOT NULL,
      database_name VARCHAR(255) NOT NULL,
      username VARCHAR(255) NOT NULL,
      encrypted_password TEXT NOT NULL,
      ssl_enabled BOOLEAN DEFAULT false,
      status VARCHAR(50) DEFAULT 'active',
      last_tested TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`
  ];

  for (const table of tables) {
    try {
      await connection.query(table);
    } catch (error) {
      console.error('Error creating table:', error);
      throw error;
    }
  }
}

export const db = DatabaseManager.getInstance();
