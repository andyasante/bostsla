"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useServices } from "./service-context";
import {
  Plus,
  Save,
  AlertTriangle,
  Server,
  Settings,
  Calendar,
  Clock,
  Target
} from "lucide-react";
import { useState } from "react";

interface ServiceForm {
  name: string;
  department: string;
  endpoint: string;
  slaTarget: string;
  responseTimeTarget: string;
  priority: string;
  monitoring: boolean;
}

interface IncidentForm {
  title: string;
  description: string;
  severity: string;
  affectedServices: string[];
  assignee: string;
  department: string;
  estimatedResolution: string;
}

interface SLAConfigForm {
  serviceName: string;
  availabilityTarget: string;
  responseTimeTarget: string;
  resolutionTimeTarget: string;
  escalationThreshold: string;
  notificationEmails: string;
  monitoringInterval: string;
}

export function UserInputForms() {
  const { addService, addIncident, updateService, services } = useServices();

  const [serviceForm, setServiceForm] = useState<ServiceForm>({
    name: "",
    department: "",
    endpoint: "",
    slaTarget: "",
    responseTimeTarget: "",
    priority: "",
    monitoring: true
  });

  const [incidentForm, setIncidentForm] = useState<IncidentForm>({
    title: "",
    description: "",
    severity: "",
    affectedServices: [],
    assignee: "",
    department: "",
    estimatedResolution: ""
  });

  const [slaForm, setSlaForm] = useState<SLAConfigForm>({
    serviceName: "",
    availabilityTarget: "",
    responseTimeTarget: "",
    resolutionTimeTarget: "",
    escalationThreshold: "",
    notificationEmails: "",
    monitoringInterval: ""
  });

  const [submitStatus, setSubmitStatus] = useState<{
    type: "success" | "error" | null;
    message: string;
  }>({ type: null, message: "" });

  const handleServiceSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    try {
      // Validate required fields
      if (!serviceForm.name || !serviceForm.department) {
        setSubmitStatus({
          type: "error",
          message: "Service name and department are required"
        });
        return;
      }

      // Add the service
      addService({
        name: serviceForm.name,
        department: serviceForm.department,
        endpoint: serviceForm.endpoint || `/api/${serviceForm.name.toLowerCase().replace(/\s+/g, '-')}`,
        status: "operational",
        slaTarget: serviceForm.slaTarget ? Number.parseFloat(serviceForm.slaTarget) : 99.0,
        responseTimeTarget: serviceForm.responseTimeTarget ? Number.parseInt(serviceForm.responseTimeTarget) : 3,
        priority: serviceForm.priority || "medium",
        monitoringEnabled: serviceForm.monitoring,
        uptime: 100.0,
        responseTime: "N/A",
        slaCompliance: serviceForm.slaTarget ? Number.parseFloat(serviceForm.slaTarget) : 99.0,
        lastIncident: "Never"
      });

      // Reset form
      setServiceForm({
        name: "",
        department: "",
        endpoint: "",
        slaTarget: "",
        responseTimeTarget: "",
        priority: "",
        monitoring: true
      });

      setSubmitStatus({
        type: "success",
        message: `Service "${serviceForm.name}" has been successfully added to the monitoring dashboard!`
      });

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSubmitStatus({ type: null, message: "" });
      }, 3000);

    } catch (error) {
      setSubmitStatus({
        type: "error",
        message: "Failed to add service. Please try again."
      });
    }
  };

  const handleIncidentSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    try {
      // Validate required fields
      if (!incidentForm.title || !incidentForm.description || !incidentForm.severity) {
        setSubmitStatus({
          type: "error",
          message: "Title, description, and severity are required"
        });
        return;
      }

      // Add the incident
      addIncident({
        title: incidentForm.title,
        description: incidentForm.description,
        severity: incidentForm.severity as "critical" | "high" | "medium" | "low",
        department: incidentForm.department,
        status: "open",
        assignee: incidentForm.assignee || "Unassigned",
        affectedServices: incidentForm.affectedServices,
        estimatedResolution: incidentForm.estimatedResolution
      });

      // Reset form
      setIncidentForm({
        title: "",
        description: "",
        severity: "",
        affectedServices: [],
        assignee: "",
        department: "",
        estimatedResolution: ""
      });

      setSubmitStatus({
        type: "success",
        message: `Incident "${incidentForm.title}" has been reported successfully!`
      });

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSubmitStatus({ type: null, message: "" });
      }, 3000);

    } catch (error) {
      setSubmitStatus({
        type: "error",
        message: "Failed to report incident. Please try again."
      });
    }
  };

  const handleSLASubmit = (e: React.FormEvent) => {
    e.preventDefault();

    try {
      // Find the service and update its SLA configuration
      const service = services.find(s => s.id === slaForm.serviceName || s.name === slaForm.serviceName);

      if (!service) {
        setSubmitStatus({
          type: "error",
          message: "Service not found"
        });
        return;
      }

      updateService(service.id, {
        slaTarget: slaForm.availabilityTarget ? Number.parseFloat(slaForm.availabilityTarget) : service.slaTarget,
        responseTimeTarget: slaForm.responseTimeTarget ? Number.parseInt(slaForm.responseTimeTarget) : service.responseTimeTarget
      });

      // Reset form
      setSlaForm({
        serviceName: "",
        availabilityTarget: "",
        responseTimeTarget: "",
        resolutionTimeTarget: "",
        escalationThreshold: "",
        notificationEmails: "",
        monitoringInterval: ""
      });

      setSubmitStatus({
        type: "success",
        message: `SLA configuration for "${service.name}" has been updated successfully!`
      });

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSubmitStatus({ type: null, message: "" });
      }, 3000);

    } catch (error) {
      setSubmitStatus({
        type: "error",
        message: "Failed to update SLA configuration. Please try again."
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">User Input & Configuration</h2>
        <p className="text-gray-500">Add new services, report incidents, and configure SLA parameters</p>
      </div>

      {/* Status Messages */}
      {submitStatus.type && (
        <Alert className={submitStatus.type === "success" ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
          <AlertDescription className={submitStatus.type === "success" ? "text-green-800" : "text-red-800"}>
            {submitStatus.message}
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="services" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="services">Add Service</TabsTrigger>
          <TabsTrigger value="incidents">Report Incident</TabsTrigger>
          <TabsTrigger value="sla-config">SLA Configuration</TabsTrigger>
        </TabsList>

        <TabsContent value="services" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Server className="h-5 w-5" />
                <span>Add New Service</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleServiceSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="service-name">Service Name *</Label>
                    <Input
                      id="service-name"
                      placeholder="e.g., Employee Portal"
                      value={serviceForm.name}
                      onChange={(e) => setServiceForm({...serviceForm, name: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="department">Department *</Label>
                    <Select value={serviceForm.department} onValueChange={(value) => setServiceForm({...serviceForm, department: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="md-secretariat">MD's Secretariat</SelectItem>
                        <SelectItem value="corporate-planning">Corporate Planning</SelectItem>
                        <SelectItem value="legal">Legal</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="terminal-transmissions">Terminal & Transmissions</SelectItem>
                        <SelectItem value="fuel-trading">Fuel Trading</SelectItem>
                        <SelectItem value="it">IT</SelectItem>
                        <SelectItem value="procurement-supply">Procurement & Supply Chain</SelectItem>
                        <SelectItem value="audit">Audit</SelectItem>
                        <SelectItem value="hr-admin">Human Resources & Administration</SelectItem>
                        <SelectItem value="corporate-comms">Corporate Communications & External Affairs</SelectItem>
                        <SelectItem value="assets-infrastructure">Assets & Infrastructure</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="endpoint">Service Endpoint</Label>
                  <Input
                    id="endpoint"
                    placeholder="https://portal.bost.gov.gh/api/health"
                    value={serviceForm.endpoint}
                    onChange={(e) => setServiceForm({...serviceForm, endpoint: e.target.value})}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="sla-target">SLA Target (%)</Label>
                    <Input
                      id="sla-target"
                      placeholder="99.5"
                      type="number"
                      step="0.1"
                      value={serviceForm.slaTarget}
                      onChange={(e) => setServiceForm({...serviceForm, slaTarget: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="response-target">Response Time Target (seconds)</Label>
                    <Input
                      id="response-target"
                      placeholder="3"
                      type="number"
                      value={serviceForm.responseTimeTarget}
                      onChange={(e) => setServiceForm({...serviceForm, responseTimeTarget: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="priority">Priority Level</Label>
                    <Select value={serviceForm.priority} onValueChange={(value) => setServiceForm({...serviceForm, priority: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="critical">Critical</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="monitoring"
                    checked={serviceForm.monitoring}
                    onCheckedChange={(checked) => setServiceForm({...serviceForm, monitoring: checked})}
                  />
                  <Label htmlFor="monitoring">Enable Active Monitoring</Label>
                </div>

                <Button type="submit" className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Service
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="incidents" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5" />
                <span>Report New Incident</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleIncidentSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="incident-title">Incident Title *</Label>
                  <Input
                    id="incident-title"
                    placeholder="e.g., Employee Portal Login Issues"
                    value={incidentForm.title}
                    onChange={(e) => setIncidentForm({...incidentForm, title: e.target.value})}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="incident-description">Description *</Label>
                  <Textarea
                    id="incident-description"
                    placeholder="Detailed description of the incident..."
                    value={incidentForm.description}
                    onChange={(e) => setIncidentForm({...incidentForm, description: e.target.value})}
                    rows={4}
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="incident-severity">Severity Level *</Label>
                    <Select value={incidentForm.severity} onValueChange={(value) => setIncidentForm({...incidentForm, severity: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select severity" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="critical">Critical</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="incident-department">Affected Department</Label>
                    <Select value={incidentForm.department} onValueChange={(value) => setIncidentForm({...incidentForm, department: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="md-secretariat">MD's Secretariat</SelectItem>
                        <SelectItem value="corporate-planning">Corporate Planning</SelectItem>
                        <SelectItem value="legal">Legal</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="terminal-transmissions">Terminal & Transmissions</SelectItem>
                        <SelectItem value="fuel-trading">Fuel Trading</SelectItem>
                        <SelectItem value="it">IT</SelectItem>
                        <SelectItem value="procurement-supply">Procurement & Supply Chain</SelectItem>
                        <SelectItem value="audit">Audit</SelectItem>
                        <SelectItem value="hr-admin">Human Resources & Administration</SelectItem>
                        <SelectItem value="corporate-comms">Corporate Communications & External Affairs</SelectItem>
                        <SelectItem value="assets-infrastructure">Assets & Infrastructure</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="incident-assignee">Assign To</Label>
                    <Input
                      id="incident-assignee"
                      placeholder="e.g., John Smith"
                      value={incidentForm.assignee}
                      onChange={(e) => setIncidentForm({...incidentForm, assignee: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="estimated-resolution">Estimated Resolution</Label>
                    <Input
                      id="estimated-resolution"
                      placeholder="e.g., 2 hours"
                      value={incidentForm.estimatedResolution}
                      onChange={(e) => setIncidentForm({...incidentForm, estimatedResolution: e.target.value})}
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Report Incident
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sla-config" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-5 w-5" />
                <span>SLA Configuration</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSLASubmit} className="space-y-4">
                <div>
                  <Label htmlFor="sla-service">Service Name</Label>
                  <Select value={slaForm.serviceName} onValueChange={(value) => setSlaForm({...slaForm, serviceName: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select service" />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((service) => (
                        <SelectItem key={service.id} value={service.id}>
                          {service.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="availability-target">Availability Target (%)</Label>
                    <Input
                      id="availability-target"
                      placeholder="99.5"
                      type="number"
                      step="0.1"
                      value={slaForm.availabilityTarget}
                      onChange={(e) => setSlaForm({...slaForm, availabilityTarget: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="response-time-target">Response Time (seconds)</Label>
                    <Input
                      id="response-time-target"
                      placeholder="3"
                      type="number"
                      value={slaForm.responseTimeTarget}
                      onChange={(e) => setSlaForm({...slaForm, responseTimeTarget: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="resolution-time-target">Resolution Time (minutes)</Label>
                    <Input
                      id="resolution-time-target"
                      placeholder="60"
                      type="number"
                      value={slaForm.resolutionTimeTarget}
                      onChange={(e) => setSlaForm({...slaForm, resolutionTimeTarget: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="escalation-threshold">Escalation Threshold (%)</Label>
                    <Input
                      id="escalation-threshold"
                      placeholder="95"
                      type="number"
                      value={slaForm.escalationThreshold}
                      onChange={(e) => setSlaForm({...slaForm, escalationThreshold: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="monitoring-interval">Monitoring Interval (minutes)</Label>
                    <Input
                      id="monitoring-interval"
                      placeholder="5"
                      type="number"
                      value={slaForm.monitoringInterval}
                      onChange={(e) => setSlaForm({...slaForm, monitoringInterval: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="notification-emails">Notification Emails</Label>
                  <Input
                    id="notification-emails"
                    placeholder="admin@bost.gov.gh, ops@bost.gov.gh"
                    value={slaForm.notificationEmails}
                    onChange={(e) => setSlaForm({...slaForm, notificationEmails: e.target.value})}
                  />
                </div>

                <Button type="submit" className="w-full">
                  <Save className="h-4 w-4 mr-2" />
                  Save SLA Configuration
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
