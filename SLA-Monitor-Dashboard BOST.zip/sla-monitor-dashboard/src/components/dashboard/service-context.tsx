"use client";

import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

export interface Service {
  id: string;
  name: string;
  department: string;
  endpoint: string;
  status: "operational" | "degraded" | "outage" | "maintenance";
  uptime: number;
  responseTime: string;
  slaCompliance: number;
  lastIncident: string;
  slaTarget?: number;
  responseTimeTarget?: number;
  priority?: string;
  monitoringEnabled?: boolean;
  createdAt: string;
}

export interface Incident {
  id: string;
  title: string;
  description: string;
  severity: "critical" | "high" | "medium" | "low";
  department: string;
  status: "open" | "investigating" | "resolved" | "closed";
  assignee: string;
  affectedServices: string[];
  estimatedResolution?: string;
  createdAt: string;
}

interface ServiceContextType {
  services: Service[];
  incidents: Incident[];
  addService: (service: Omit<Service, "id" | "createdAt">) => void;
  updateService: (id: string, updates: Partial<Service>) => void;
  deleteService: (id: string) => void;
  addIncident: (incident: Omit<Incident, "id" | "createdAt">) => void;
  updateIncident: (id: string, updates: Partial<Incident>) => void;
  deleteIncident: (id: string) => void;
  getServicesByDepartment: (department: string) => Service[];
  getIncidentsByService: (serviceId: string) => Incident[];
}

const ServiceContext = createContext<ServiceContextType | undefined>(undefined);

// Initial data - this would come from your database
const initialServices: Service[] = [
  {
    id: "srv-001",
    name: "BOST Employee Portal",
    department: "Human Resources & Administration",
    status: "operational",
    uptime: 99.8,
    responseTime: "1.2s",
    slaCompliance: 99.5,
    lastIncident: "3 days ago",
    endpoint: "/hr/portal",
    slaTarget: 99.5,
    responseTimeTarget: 3,
    priority: "high",
    monitoringEnabled: true,
    createdAt: new Date().toISOString()
  },
  {
    id: "srv-002",
    name: "Financial Management System",
    department: "Finance",
    status: "operational",
    uptime: 99.9,
    responseTime: "0.8s",
    slaCompliance: 99.8,
    lastIncident: "1 week ago",
    endpoint: "/finance/fms",
    slaTarget: 99.5,
    responseTimeTarget: 2,
    priority: "critical",
    monitoringEnabled: true,
    createdAt: new Date().toISOString()
  },
  {
    id: "srv-003",
    name: "Terminal Operations Management",
    department: "Terminal & Transmissions",
    status: "degraded",
    uptime: 98.5,
    responseTime: "3.2s",
    slaCompliance: 97.8,
    lastIncident: "2 hours ago",
    endpoint: "/terminal/operations",
    slaTarget: 99.0,
    responseTimeTarget: 3,
    priority: "high",
    monitoringEnabled: true,
    createdAt: new Date().toISOString()
  },
  {
    id: "srv-004",
    name: "Document Management System",
    department: "IT",
    status: "operational",
    uptime: 99.7,
    responseTime: "1.5s",
    slaCompliance: 99.2,
    lastIncident: "5 days ago",
    endpoint: "/it/docs",
    slaTarget: 99.0,
    responseTimeTarget: 2,
    priority: "medium",
    monitoringEnabled: true,
    createdAt: new Date().toISOString()
  },
  {
    id: "srv-005",
    name: "Procurement & Supply Chain System",
    department: "Procurement & Supply Chain",
    status: "maintenance",
    uptime: 95.0,
    responseTime: "N/A",
    slaCompliance: 95.0,
    lastIncident: "Scheduled maintenance",
    endpoint: "/procurement/system",
    slaTarget: 98.0,
    responseTimeTarget: 5,
    priority: "medium",
    monitoringEnabled: false,
    createdAt: new Date().toISOString()
  },
  {
    id: "srv-006",
    name: "Fuel Trading Platform",
    department: "Fuel Trading",
    status: "operational",
    uptime: 99.6,
    responseTime: "2.1s",
    slaCompliance: 99.1,
    lastIncident: "1 day ago",
    endpoint: "/trading/platform",
    slaTarget: 99.0,
    responseTimeTarget: 3,
    priority: "critical",
    monitoringEnabled: true,
    createdAt: new Date().toISOString()
  },
  {
    id: "srv-007",
    name: "Asset Management System",
    department: "Assets & Infrastructure",
    status: "outage",
    uptime: 92.3,
    responseTime: "N/A",
    slaCompliance: 92.3,
    lastIncident: "30 minutes ago",
    endpoint: "/assets/management",
    slaTarget: 99.0,
    responseTimeTarget: 3,
    priority: "high",
    monitoringEnabled: true,
    createdAt: new Date().toISOString()
  },
  {
    id: "srv-008",
    name: "Executive Dashboard",
    department: "MD's Secretariat",
    status: "operational",
    uptime: 99.9,
    responseTime: "1.1s",
    slaCompliance: 99.7,
    lastIncident: "2 weeks ago",
    endpoint: "/executive/dashboard",
    slaTarget: 99.5,
    responseTimeTarget: 2,
    priority: "critical",
    monitoringEnabled: true,
    createdAt: new Date().toISOString()
  }
];

const initialIncidents: Incident[] = [];

export function ServiceProvider({ children }: { children: ReactNode }) {
  const [services, setServices] = useState<Service[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedServices = localStorage.getItem("bost-sla-services");
    const savedIncidents = localStorage.getItem("bost-sla-incidents");

    if (savedServices) {
      setServices(JSON.parse(savedServices));
    } else {
      setServices(initialServices);
    }

    if (savedIncidents) {
      setIncidents(JSON.parse(savedIncidents));
    } else {
      setIncidents(initialIncidents);
    }
  }, []);

  // Save to localStorage whenever data changes
  useEffect(() => {
    if (services.length > 0) {
      localStorage.setItem("bost-sla-services", JSON.stringify(services));
    }
  }, [services]);

  useEffect(() => {
    localStorage.setItem("bost-sla-incidents", JSON.stringify(incidents));
  }, [incidents]);

  const addService = (serviceData: Omit<Service, "id" | "createdAt">) => {
    const newService: Service = {
      ...serviceData,
      id: `srv-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
      // Set default values if not provided
      uptime: 100.0,
      responseTime: "N/A",
      slaCompliance: serviceData.slaTarget || 99.0,
      lastIncident: "Never",
      status: "operational"
    };

    setServices(prev => [...prev, newService]);
  };

  const updateService = (id: string, updates: Partial<Service>) => {
    setServices(prev =>
      prev.map(service =>
        service.id === id ? { ...service, ...updates } : service
      )
    );
  };

  const deleteService = (id: string) => {
    setServices(prev => prev.filter(service => service.id !== id));
  };

  const addIncident = (incidentData: Omit<Incident, "id" | "createdAt">) => {
    const newIncident: Incident = {
      ...incidentData,
      id: `inc-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString()
    };

    setIncidents(prev => [...prev, newIncident]);
  };

  const updateIncident = (id: string, updates: Partial<Incident>) => {
    setIncidents(prev =>
      prev.map(incident =>
        incident.id === id ? { ...incident, ...updates } : incident
      )
    );
  };

  const deleteIncident = (id: string) => {
    setIncidents(prev => prev.filter(incident => incident.id !== id));
  };

  const getServicesByDepartment = (department: string) => {
    return services.filter(service => service.department === department);
  };

  const getIncidentsByService = (serviceId: string) => {
    return incidents.filter(incident =>
      incident.affectedServices.includes(serviceId)
    );
  };

  return (
    <ServiceContext.Provider
      value={{
        services,
        incidents,
        addService,
        updateService,
        deleteService,
        addIncident,
        updateIncident,
        deleteIncident,
        getServicesByDepartment,
        getIncidentsByService,
      }}
    >
      {children}
    </ServiceContext.Provider>
  );
}

export function useServices() {
  const context = useContext(ServiceContext);
  if (context === undefined) {
    throw new Error("useServices must be used within a ServiceProvider");
  }
  return context;
}
