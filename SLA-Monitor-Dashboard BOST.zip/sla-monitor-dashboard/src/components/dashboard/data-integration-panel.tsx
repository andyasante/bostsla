"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Database,
  Globe,
  Upload,
  Settings,
  Plus,
  CheckCircle,
  AlertCircle,
  Clock,
  Zap,
  RefreshCw
} from "lucide-react";
import { useState } from "react";
import { AdvancedConnectors } from "./advanced-connectors";
import { DatabaseConnection } from "./database-connection";

interface DataSource {
  id: string;
  name: string;
  type: "database" | "api" | "file" | "webhook";
  status: "connected" | "disconnected" | "pending";
  lastSync: string;
  recordCount?: number;
}

const connectedSources: DataSource[] = [
  {
    id: "postgres-main",
    name: "BOST Main Database",
    type: "database",
    status: "connected",
    lastSync: "2 minutes ago",
    recordCount: 1247
  },
  {
    id: "monitoring-api",
    name: "Prometheus Monitoring",
    type: "api",
    status: "connected",
    lastSync: "30 seconds ago",
    recordCount: 856
  },
  {
    id: "incident-webhook",
    name: "Incident Management Webhook",
    type: "webhook",
    status: "pending",
    lastSync: "Never",
  }
];

function getStatusIcon(status: string) {
  switch (status) {
    case "connected":
      return <CheckCircle className="h-4 w-4 text-green-600" />;
    case "pending":
      return <Clock className="h-4 w-4 text-yellow-600" />;
    default:
      return <AlertCircle className="h-4 w-4 text-red-600" />;
  }
}

function getStatusBadge(status: string) {
  switch (status) {
    case "connected":
      return <Badge className="bg-green-100 text-green-800">Connected</Badge>;
    case "pending":
      return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
    default:
      return <Badge className="bg-red-100 text-red-800">Disconnected</Badge>;
  }
}

export function DataIntegrationPanel() {
  const [activeTab, setActiveTab] = useState("sources");
  const [newApiUrl, setNewApiUrl] = useState("");
  const [newDbConnection, setNewDbConnection] = useState({
    host: "",
    port: "",
    database: "",
    username: "",
    password: ""
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Data Integration</h2>
          <p className="text-gray-500">Connect external data sources and configure real-time updates</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Data Source
        </Button>
      </div>

      <Tabs defaultValue="sources" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="sources">Data Sources</TabsTrigger>
          <TabsTrigger value="database">Database</TabsTrigger>
          <TabsTrigger value="apis">APIs</TabsTrigger>
          <TabsTrigger value="upload">File Upload</TabsTrigger>
          <TabsTrigger value="advanced">Advanced</TabsTrigger>
        </TabsList>

        <TabsContent value="sources" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Connected Data Sources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {connectedSources.map((source) => (
                  <div key={source.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        {source.type === "database" && <Database className="h-5 w-5 text-blue-600" />}
                        {source.type === "api" && <Globe className="h-5 w-5 text-green-600" />}
                        {source.type === "webhook" && <Settings className="h-5 w-5 text-purple-600" />}
                        {getStatusIcon(source.status)}
                      </div>
                      <div>
                        <h4 className="font-medium">{source.name}</h4>
                        <p className="text-sm text-gray-500">
                          Last sync: {source.lastSync}
                          {source.recordCount && ` • ${source.recordCount} records`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusBadge(source.status)}
                      <Button variant="outline" size="sm">
                        Configure
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="database" className="space-y-4">
          <DatabaseConnection />
        </TabsContent>

        <TabsContent value="database-old" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Database Connection</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="host">Host</Label>
                  <Input
                    id="host"
                    placeholder="localhost"
                    value={newDbConnection.host}
                    onChange={(e) => setNewDbConnection({...newDbConnection, host: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="port">Port</Label>
                  <Input
                    id="port"
                    placeholder="5432"
                    value={newDbConnection.port}
                    onChange={(e) => setNewDbConnection({...newDbConnection, port: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="database">Database Name</Label>
                <Input
                  id="database"
                  placeholder="bost_monitoring"
                  value={newDbConnection.database}
                  onChange={(e) => setNewDbConnection({...newDbConnection, database: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    placeholder="admin"
                    value={newDbConnection.username}
                    onChange={(e) => setNewDbConnection({...newDbConnection, username: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={newDbConnection.password}
                    onChange={(e) => setNewDbConnection({...newDbConnection, password: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Supported Database Types:</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">PostgreSQL</Badge>
                  <Badge variant="outline">MySQL</Badge>
                  <Badge variant="outline">MongoDB</Badge>
                  <Badge variant="outline">SQL Server</Badge>
                  <Badge variant="outline">Oracle</Badge>
                </div>
              </div>

              <Button className="w-full">Test Connection</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="apis" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>API Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="api-url">API Endpoint URL</Label>
                <Input
                  id="api-url"
                  placeholder="https://api.example.com/v1/metrics"
                  value={newApiUrl}
                  onChange={(e) => setNewApiUrl(e.target.value)}
                />
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Pre-configured Integrations:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h5 className="font-medium mb-2">Prometheus</h5>
                    <p className="text-sm text-gray-600 mb-3">Monitor system metrics and performance</p>
                    <Button variant="outline" size="sm" className="w-full">Connect</Button>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h5 className="font-medium mb-2">Grafana</h5>
                    <p className="text-sm text-gray-600 mb-3">Import dashboard and visualization data</p>
                    <Button variant="outline" size="sm" className="w-full">Connect</Button>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h5 className="font-medium mb-2">Nagios</h5>
                    <p className="text-sm text-gray-600 mb-3">Network and infrastructure monitoring</p>
                    <Button variant="outline" size="sm" className="w-full">Connect</Button>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h5 className="font-medium mb-2">PagerDuty</h5>
                    <p className="text-sm text-gray-600 mb-3">Incident management and alerting</p>
                    <Button variant="outline" size="sm" className="w-full">Connect</Button>
                  </div>
                </div>
              </div>

              <Button className="w-full">Add Custom API</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upload" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>File Upload & Import</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <h4 className="font-medium mb-2">Drop files here or click to upload</h4>
                <p className="text-sm text-gray-500 mb-4">
                  Support for CSV, JSON, Excel files up to 10MB
                </p>
                <Button variant="outline">Choose Files</Button>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Supported File Formats:</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">CSV</Badge>
                  <Badge variant="outline">JSON</Badge>
                  <Badge variant="outline">Excel (.xlsx)</Badge>
                  <Badge variant="outline">XML</Badge>
                  <Badge variant="outline">Log Files</Badge>
                </div>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg">
                <h5 className="font-medium text-blue-900 mb-2">Sample Data Templates</h5>
                <p className="text-sm text-blue-800 mb-3">
                  Download templates to see the expected data format
                </p>
                <div className="space-x-2">
                  <Button variant="outline" size="sm">Service Data Template</Button>
                  <Button variant="outline" size="sm">Incident Data Template</Button>
                  <Button variant="outline" size="sm">SLA Metrics Template</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
