"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Cloud,
  Database,
  Shield,
  MessageSquare,
  GitBranch,
  Zap,
  Server,
  Monitor,
  Settings,
  CheckCircle,
  AlertCircle,
  Clock,
  Plus,
  Download,
  Upload,
  Wifi,
  BarChart3,
  Bell
} from "lucide-react";
import { useState } from "react";

interface Connector {
  id: string;
  name: string;
  category: string;
  description: string;
  icon: any;
  status: "connected" | "available" | "configuring";
  features: string[];
  setupTime: string;
  dataTypes: string[];
}

const enterpriseConnectors: Connector[] = [
  {
    id: "sap-erp",
    name: "SAP ERP",
    category: "Enterprise",
    description: "Connect to SAP systems for financial and operational data",
    icon: Database,
    status: "available",
    features: ["Real-time data", "Scheduled sync", "Custom queries"],
    setupTime: "15 min",
    dataTypes: ["Financial metrics", "User activity", "System performance"]
  },
  {
    id: "oracle-erp",
    name: "Oracle ERP Cloud",
    category: "Enterprise",
    description: "Integration with Oracle Enterprise Resource Planning",
    icon: Database,
    status: "available",
    features: ["API integration", "Bulk data import", "Real-time alerts"],
    setupTime: "10 min",
    dataTypes: ["Business processes", "Financial data", "HR metrics"]
  },
  {
    id: "microsoft-dynamics",
    name: "Microsoft Dynamics 365",
    category: "Enterprise",
    description: "Connect to Dynamics 365 for business operations data",
    icon: Database,
    status: "connected",
    features: ["OAuth 2.0", "Webhook support", "Field mapping"],
    setupTime: "12 min",
    dataTypes: ["CRM data", "Sales metrics", "Customer service"]
  }
];

const cloudConnectors: Connector[] = [
  {
    id: "aws-cloudwatch",
    name: "AWS CloudWatch",
    category: "Cloud",
    description: "Monitor AWS infrastructure and application metrics",
    icon: Cloud,
    status: "connected",
    features: ["Metrics collection", "Log analysis", "Custom dashboards"],
    setupTime: "8 min",
    dataTypes: ["Infrastructure metrics", "Application logs", "Cost data"]
  },
  {
    id: "azure-monitor",
    name: "Azure Monitor",
    category: "Cloud",
    description: "Comprehensive monitoring for Azure resources",
    icon: Cloud,
    status: "available",
    features: ["Application insights", "Log analytics", "Alerts"],
    setupTime: "10 min",
    dataTypes: ["VM performance", "App metrics", "Network data"]
  },
  {
    id: "google-cloud-monitoring",
    name: "Google Cloud Monitoring",
    category: "Cloud",
    description: "Monitor Google Cloud Platform resources and services",
    icon: Cloud,
    status: "available",
    features: ["Stackdriver integration", "Custom metrics", "Uptime monitoring"],
    setupTime: "7 min",
    dataTypes: ["GCP resources", "Application performance", "Error rates"]
  }
];

const monitoringConnectors: Connector[] = [
  {
    id: "splunk",
    name: "Splunk Enterprise",
    category: "Monitoring",
    description: "Search, monitor and analyze machine-generated data",
    icon: BarChart3,
    status: "available",
    features: ["Log analysis", "Real-time search", "Custom alerts"],
    setupTime: "20 min",
    dataTypes: ["System logs", "Security events", "Performance data"]
  },
  {
    id: "elasticsearch",
    name: "Elasticsearch",
    category: "Monitoring",
    description: "Distributed search and analytics engine",
    icon: BarChart3,
    status: "configuring",
    features: ["Full-text search", "Real-time analytics", "Data visualization"],
    setupTime: "15 min",
    dataTypes: ["Log data", "Metrics", "Business analytics"]
  },
  {
    id: "zabbix",
    name: "Zabbix",
    category: "Monitoring",
    description: "Enterprise-class monitoring solution",
    icon: Monitor,
    status: "available",
    features: ["Network monitoring", "Auto-discovery", "Predictive functions"],
    setupTime: "18 min",
    dataTypes: ["Network performance", "Server metrics", "Application data"]
  },
  {
    id: "solarwinds",
    name: "SolarWinds NPM",
    category: "Monitoring",
    description: "Network performance monitoring and management",
    icon: Wifi,
    status: "available",
    features: ["SNMP monitoring", "Bandwidth analysis", "Alerting"],
    setupTime: "12 min",
    dataTypes: ["Network topology", "Bandwidth usage", "Device status"]
  }
];

const communicationConnectors: Connector[] = [
  {
    id: "slack",
    name: "Slack",
    category: "Communication",
    description: "Send alerts and notifications to Slack channels",
    icon: MessageSquare,
    status: "connected",
    features: ["Webhook integration", "Bot commands", "Interactive alerts"],
    setupTime: "3 min",
    dataTypes: ["Alert notifications", "Status updates", "Incident reports"]
  },
  {
    id: "microsoft-teams",
    name: "Microsoft Teams",
    category: "Communication",
    description: "Integrate with Teams for collaboration and alerts",
    icon: MessageSquare,
    status: "available",
    features: ["Bot framework", "Adaptive cards", "Channel notifications"],
    setupTime: "5 min",
    dataTypes: ["Team notifications", "Alert messages", "Status reports"]
  },
  {
    id: "servicenow",
    name: "ServiceNow",
    category: "Communication",
    description: "IT service management and incident tracking",
    icon: Settings,
    status: "available",
    features: ["Incident creation", "Status sync", "Workflow automation"],
    setupTime: "25 min",
    dataTypes: ["Incident tickets", "Change requests", "Asset data"]
  },
  {
    id: "jira",
    name: "Atlassian Jira",
    category: "Communication",
    description: "Issue tracking and project management integration",
    icon: Settings,
    status: "available",
    features: ["Issue creation", "Status tracking", "Custom fields"],
    setupTime: "8 min",
    dataTypes: ["Issue data", "Project metrics", "Sprint information"]
  }
];

const advancedConnectors: Connector[] = [
  {
    id: "kafka",
    name: "Apache Kafka",
    category: "Streaming",
    description: "Distributed event streaming platform",
    icon: Zap,
    status: "available",
    features: ["Real-time streaming", "Event processing", "High throughput"],
    setupTime: "30 min",
    dataTypes: ["Event streams", "Message queues", "Real-time data"]
  },
  {
    id: "rabbitmq",
    name: "RabbitMQ",
    category: "Streaming",
    description: "Message broker for reliable message delivery",
    icon: Zap,
    status: "available",
    features: ["Message queuing", "Routing", "Clustering"],
    setupTime: "20 min",
    dataTypes: ["Message queues", "Event notifications", "Task queues"]
  },
  {
    id: "redis",
    name: "Redis",
    category: "Database",
    description: "In-memory data structure store and cache",
    icon: Database,
    status: "available",
    features: ["Caching", "Pub/Sub", "Real-time analytics"],
    setupTime: "10 min",
    dataTypes: ["Cache metrics", "Session data", "Real-time counters"]
  }
];

function getStatusIcon(status: string) {
  switch (status) {
    case "connected":
      return <CheckCircle className="h-4 w-4 text-green-600" />;
    case "configuring":
      return <Clock className="h-4 w-4 text-yellow-600" />;
    default:
      return <AlertCircle className="h-4 w-4 text-gray-400" />;
  }
}

function getStatusBadge(status: string) {
  switch (status) {
    case "connected":
      return <Badge className="bg-green-100 text-green-800">Connected</Badge>;
    case "configuring":
      return <Badge className="bg-yellow-100 text-yellow-800">Configuring</Badge>;
    default:
      return <Badge variant="outline">Available</Badge>;
  }
}

export function AdvancedConnectors() {
  const [selectedConnector, setSelectedConnector] = useState<Connector | null>(null);
  const [configForm, setConfigForm] = useState({
    apiKey: "",
    endpoint: "",
    username: "",
    password: "",
    region: "",
    enableSync: true,
    syncInterval: "5"
  });

  const allConnectors = [
    ...enterpriseConnectors,
    ...cloudConnectors,
    ...monitoringConnectors,
    ...communicationConnectors,
    ...advancedConnectors
  ];

  const ConnectorCard = ({ connector }: { connector: Connector }) => {
    const Icon = connector.icon;
    return (
      <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedConnector(connector)}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Icon className="h-8 w-8 text-blue-600" />
              <div>
                <CardTitle className="text-base">{connector.name}</CardTitle>
                <Badge variant="outline" className="mt-1">{connector.category}</Badge>
              </div>
            </div>
            {getStatusIcon(connector.status)}
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 mb-3">{connector.description}</p>
          <div className="flex items-center justify-between">
            {getStatusBadge(connector.status)}
            <span className="text-xs text-gray-500">⏱ {connector.setupTime}</span>
          </div>
          <div className="mt-3">
            <div className="flex flex-wrap gap-1">
              {connector.dataTypes.slice(0, 2).map((type) => (
                <Badge key={type} variant="secondary" className="text-xs">{type}</Badge>
              ))}
              {connector.dataTypes.length > 2 && (
                <Badge variant="secondary" className="text-xs">+{connector.dataTypes.length - 2} more</Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Advanced Data Connectors</h2>
          <p className="text-gray-500">Connect to enterprise systems, cloud platforms, and monitoring tools</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Import Config
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Custom Connector
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="enterprise">Enterprise</TabsTrigger>
          <TabsTrigger value="cloud">Cloud</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          <TabsTrigger value="communication">Communication</TabsTrigger>
          <TabsTrigger value="streaming">Streaming</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {allConnectors.filter(c => c.status === "connected").map((connector) => (
              <ConnectorCard key={connector.id} connector={connector} />
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Integration Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div className="p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {allConnectors.filter(c => c.status === "connected").length}
                  </div>
                  <div className="text-sm text-green-600">Connected</div>
                </div>
                <div className="p-4 bg-yellow-50 rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">
                    {allConnectors.filter(c => c.status === "configuring").length}
                  </div>
                  <div className="text-sm text-yellow-600">Configuring</div>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {allConnectors.filter(c => c.status === "available").length}
                  </div>
                  <div className="text-sm text-blue-600">Available</div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">
                    {new Set(allConnectors.map(c => c.category)).size}
                  </div>
                  <div className="text-sm text-purple-600">Categories</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="enterprise">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {enterpriseConnectors.map((connector) => (
              <ConnectorCard key={connector.id} connector={connector} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="cloud">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {cloudConnectors.map((connector) => (
              <ConnectorCard key={connector.id} connector={connector} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="monitoring">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {monitoringConnectors.map((connector) => (
              <ConnectorCard key={connector.id} connector={connector} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="communication">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {communicationConnectors.map((connector) => (
              <ConnectorCard key={connector.id} connector={connector} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="streaming">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {advancedConnectors.map((connector) => (
              <ConnectorCard key={connector.id} connector={connector} />
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Connector Configuration Modal */}
      {selectedConnector && (
        <Card className="fixed inset-4 z-50 bg-white shadow-2xl overflow-auto">
          <CardHeader className="border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {React.createElement(selectedConnector.icon, { className: "h-6 w-6 text-blue-600" })}
                <CardTitle>Configure {selectedConnector.name}</CardTitle>
              </div>
              <Button variant="ghost" onClick={() => setSelectedConnector(null)}>×</Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6 p-6">
            <div>
              <h4 className="font-medium mb-2">Connection Details</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="endpoint">Endpoint/URL</Label>
                  <Input
                    id="endpoint"
                    placeholder={`https://${selectedConnector.name.toLowerCase()}.bost.gov.gh`}
                    value={configForm.endpoint}
                    onChange={(e) => setConfigForm({...configForm, endpoint: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="api-key">API Key</Label>
                  <Input
                    id="api-key"
                    type="password"
                    placeholder="Enter API key"
                    value={configForm.apiKey}
                    onChange={(e) => setConfigForm({...configForm, apiKey: e.target.value})}
                  />
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-2">Authentication</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    placeholder="Username"
                    value={configForm.username}
                    onChange={(e) => setConfigForm({...configForm, username: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Password"
                    value={configForm.password}
                    onChange={(e) => setConfigForm({...configForm, password: e.target.value})}
                  />
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-2">Sync Configuration</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={configForm.enableSync}
                    onCheckedChange={(checked) => setConfigForm({...configForm, enableSync: checked})}
                  />
                  <Label>Enable automatic sync</Label>
                </div>
                <div>
                  <Label htmlFor="sync-interval">Sync interval (minutes)</Label>
                  <Select value={configForm.syncInterval} onValueChange={(value) => setConfigForm({...configForm, syncInterval: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 minute</SelectItem>
                      <SelectItem value="5">5 minutes</SelectItem>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-2">Data Types</h4>
              <div className="flex flex-wrap gap-2">
                {selectedConnector.dataTypes.map((type) => (
                  <Badge key={type} variant="outline">{type}</Badge>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-2">Features</h4>
              <div className="flex flex-wrap gap-2">
                {selectedConnector.features.map((feature) => (
                  <Badge key={feature} className="bg-blue-100 text-blue-800">{feature}</Badge>
                ))}
              </div>
            </div>

            <div className="flex space-x-2">
              <Button className="flex-1">
                <CheckCircle className="h-4 w-4 mr-2" />
                Test Connection
              </Button>
              <Button className="flex-1" variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Save Configuration
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
