"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useFilters } from "./filter-context";
import { useServices } from "./service-context";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import {
  CheckCircle,
  AlertTriangle,
  XCircle,
  Clock,
  ExternalLink,
  MoreHorizontal
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const serviceData = [
  {
    id: "srv-001",
    name: "BOST Employee Portal",
    department: "Human Resources & Administration",
    status: "operational",
    uptime: 99.8,
    responseTime: "1.2s",
    slaCompliance: 99.5,
    lastIncident: "3 days ago",
    endpoint: "/hr/portal"
  },
  {
    id: "srv-002",
    name: "Financial Management System",
    department: "Finance",
    status: "operational",
    uptime: 99.9,
    responseTime: "0.8s",
    slaCompliance: 99.8,
    lastIncident: "1 week ago",
    endpoint: "/finance/fms"
  },
  {
    id: "srv-003",
    name: "Terminal Operations Management",
    department: "Terminal & Transmissions",
    status: "degraded",
    uptime: 98.5,
    responseTime: "3.2s",
    slaCompliance: 97.8,
    lastIncident: "2 hours ago",
    endpoint: "/terminal/operations"
  },
  {
    id: "srv-004",
    name: "Document Management System",
    department: "IT",
    status: "operational",
    uptime: 99.7,
    responseTime: "1.5s",
    slaCompliance: 99.2,
    lastIncident: "5 days ago",
    endpoint: "/it/docs"
  },
  {
    id: "srv-005",
    name: "Procurement & Supply Chain System",
    department: "Procurement & Supply Chain",
    status: "maintenance",
    uptime: 95.0,
    responseTime: "N/A",
    slaCompliance: 95.0,
    lastIncident: "Scheduled maintenance",
    endpoint: "/procurement/system"
  },
  {
    id: "srv-006",
    name: "Fuel Trading Platform",
    department: "Fuel Trading",
    status: "operational",
    uptime: 99.6,
    responseTime: "2.1s",
    slaCompliance: 99.1,
    lastIncident: "1 day ago",
    endpoint: "/trading/platform"
  },
  {
    id: "srv-007",
    name: "Asset Management System",
    department: "Assets & Infrastructure",
    status: "outage",
    uptime: 92.3,
    responseTime: "N/A",
    slaCompliance: 92.3,
    lastIncident: "30 minutes ago",
    endpoint: "/assets/management"
  },
  {
    id: "srv-008",
    name: "Executive Dashboard",
    department: "MD's Secretariat",
    status: "operational",
    uptime: 99.9,
    responseTime: "1.1s",
    slaCompliance: 99.7,
    lastIncident: "2 weeks ago",
    endpoint: "/executive/dashboard"
  },
  {
    id: "srv-009",
    name: "Corporate Planning System",
    department: "Corporate Planning",
    status: "operational",
    uptime: 99.4,
    responseTime: "1.8s",
    slaCompliance: 99.0,
    lastIncident: "5 days ago",
    endpoint: "/planning/system"
  },
  {
    id: "srv-010",
    name: "Legal Case Management",
    department: "Legal",
    status: "operational",
    uptime: 99.6,
    responseTime: "1.3s",
    slaCompliance: 99.3,
    lastIncident: "1 week ago",
    endpoint: "/legal/cases"
  },
  {
    id: "srv-011",
    name: "Audit Management System",
    department: "Audit",
    status: "operational",
    uptime: 99.7,
    responseTime: "1.0s",
    slaCompliance: 99.4,
    lastIncident: "4 days ago",
    endpoint: "/audit/system"
  },
  {
    id: "srv-012",
    name: "Corporate Communications Portal",
    department: "Corporate Communications & External Affairs",
    status: "operational",
    uptime: 99.3,
    responseTime: "2.0s",
    slaCompliance: 98.9,
    lastIncident: "2 days ago",
    endpoint: "/communications/portal"
  }
];

function getStatusIcon(status: string) {
  switch (status) {
    case "operational":
      return <CheckCircle className="h-4 w-4 text-green-600" />;
    case "degraded":
      return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
    case "outage":
      return <XCircle className="h-4 w-4 text-red-600" />;
    case "maintenance":
      return <Clock className="h-4 w-4 text-blue-600" />;
    default:
      return <CheckCircle className="h-4 w-4 text-gray-600" />;
  }
}

function getStatusBadge(status: string) {
  switch (status) {
    case "operational":
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Operational</Badge>;
    case "degraded":
      return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Degraded</Badge>;
    case "outage":
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Outage</Badge>;
    case "maintenance":
      return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Maintenance</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
}

function getSLAColor(compliance: number) {
  if (compliance >= 99.5) return "text-green-600";
  if (compliance >= 98.0) return "text-yellow-600";
  return "text-red-600";
}

export function ServiceStatusTable() {
  const { searchTerm, selectedDepartment, selectedStatus } = useFilters();
  const { services } = useServices();

  // Filter services based on active filters
  const filteredServices = services.filter((service) => {
    const matchesSearch = !searchTerm ||
      service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesDepartment = selectedDepartment === "all" ||
      service.department.toLowerCase().includes(selectedDepartment.replace("-", " "));

    const matchesStatus = selectedStatus === "all" ||
      service.status === selectedStatus;

    return matchesSearch && matchesDepartment && matchesStatus;
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Service Status Overview
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">
              Export Report
            </Button>
            <Button variant="outline" size="sm">
              Refresh
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Service</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Uptime</TableHead>
                <TableHead>Response Time</TableHead>
                <TableHead>SLA Compliance</TableHead>
                <TableHead>Last Incident</TableHead>
                <TableHead className="w-[70px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredServices.map((service) => (
                <TableRow key={service.id}>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(service.status)}
                      <div>
                        <div className="font-medium">{service.name}</div>
                        <div className="text-sm text-gray-500">{service.id}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{service.department}</Badge>
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(service.status)}
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{service.uptime}%</span>
                      </div>
                      <Progress value={service.uptime} className="h-2" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className={`font-medium ${
                      service.responseTime === "N/A" ? "text-gray-400" :
                      Number.parseFloat(service.responseTime) < 2 ? "text-green-600" :
                      Number.parseFloat(service.responseTime) < 3 ? "text-yellow-600" : "text-red-600"
                    }`}>
                      {service.responseTime}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className={`font-medium ${getSLAColor(service.slaCompliance)}`}>
                      {service.slaCompliance}%
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-gray-600">{service.lastIncident}</span>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <ExternalLink className="mr-2 h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          View Logs
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          Performance History
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          Report Issue
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="flex items-center justify-between mt-4">
          <div className="text-sm text-gray-500">
            Showing {filteredServices.length} of {services.length} services
            {(searchTerm || selectedDepartment !== "all" || selectedStatus !== "all") &&
              <span className="ml-2 text-blue-600">(filtered)</span>
            }
          </div>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-1">
              <CheckCircle className="h-3 w-3 text-green-600" />
              <span>{filteredServices.filter(s => s.status === "operational").length} Operational</span>
            </div>
            <div className="flex items-center space-x-1">
              <AlertTriangle className="h-3 w-3 text-yellow-600" />
              <span>{filteredServices.filter(s => s.status === "degraded").length} Degraded</span>
            </div>
            <div className="flex items-center space-x-1">
              <XCircle className="h-3 w-3 text-red-600" />
              <span>{filteredServices.filter(s => s.status === "outage").length} Outage</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="h-3 w-3 text-blue-600" />
              <span>{filteredServices.filter(s => s.status === "maintenance").length} Maintenance</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
