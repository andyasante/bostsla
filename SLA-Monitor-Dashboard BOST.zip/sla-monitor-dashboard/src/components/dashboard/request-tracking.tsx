"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { useFilters } from "./filter-context";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Clock,
  Plus,
  FileText,
  CheckCircle,
  AlertTriangle,
  XCircle,
  MoreHorizontal,
  Calendar,
  User,
  Building2,
  Timer,
  Upload,
  Download,
  Filter,
  Search,
  RefreshCw
} from "lucide-react";
import { useState, useEffect } from "react";

interface Request {
  id?: number;
  request_id: string;
  requesting_department: string;
  service_department: string;
  service_type: string;
  expected_duration: number;
  request_description: string;
  attached_files: string[];
  status: 'submitted' | 'in_review' | 'approved' | 'in_progress' | 'completed' | 'rejected' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assigned_to?: string;
  submitted_by: string;
  submitted_at: string;
  updated_at: string;
  completed_at?: string;
  estimated_completion?: string;
  actual_completion?: string;
  sla_due_date: string;
  sla_status: 'on_track' | 'at_risk' | 'overdue' | 'completed_on_time' | 'completed_late';
}

interface RequestForm {
  requesting_department: string;
  service_department: string;
  service_type: string;
  request_description: string;
  attached_files: string[];
  submitted_by: string;
  priority: string;
}

const SERVICE_TYPES = {
  'Petty Cash': { duration: 48, department: 'Finance' },
  'Travel Authorization': { duration: 72, department: 'Finance' },
  'Purchase Request': { duration: 120, department: 'Procurement & Supply Chain' },
  'IT Support': { duration: 24, department: 'IT' },
  'Equipment Request': { duration: 168, department: 'Assets & Infrastructure' },
  'Leave Request': { duration: 48, department: 'Human Resources & Administration' },
  'Training Request': { duration: 120, department: 'Human Resources & Administration' },
  'Document Request': { duration: 24, department: 'Legal' },
  'Budget Approval': { duration: 72, department: 'Finance' },
  'Audit Request': { duration: 240, department: 'Audit' },
  'Communication Request': { duration: 48, department: 'Corporate Communications & External Affairs' },
  'Strategic Planning': { duration: 336, department: 'Corporate Planning' },
  'Executive Approval': { duration: 96, department: "MD's Secretariat" },
  'Terminal Access': { duration: 48, department: 'Terminal & Transmissions' },
  'Fuel Trading Authorization': { duration: 72, department: 'Fuel Trading' },
};

const DEPARTMENTS = [
  "MD's Secretariat",
  "Corporate Planning",
  "Legal",
  "Finance",
  "Terminal & Transmissions",
  "Fuel Trading",
  "IT",
  "Procurement & Supply Chain",
  "Audit",
  "Human Resources & Administration",
  "Corporate Communications & External Affairs",
  "Assets & Infrastructure"
];

function getStatusIcon(status: string) {
  switch (status) {
    case 'completed':
      return <CheckCircle className="h-4 w-4 text-green-600" />;
    case 'in_progress':
      return <Clock className="h-4 w-4 text-blue-600" />;
    case 'approved':
      return <CheckCircle className="h-4 w-4 text-green-600" />;
    case 'submitted':
    case 'in_review':
      return <Timer className="h-4 w-4 text-yellow-600" />;
    case 'rejected':
    case 'cancelled':
      return <XCircle className="h-4 w-4 text-red-600" />;
    default:
      return <Clock className="h-4 w-4 text-gray-600" />;
  }
}

function getStatusBadge(status: string) {
  switch (status) {
    case 'completed':
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Completed</Badge>;
    case 'in_progress':
      return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">In Progress</Badge>;
    case 'approved':
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>;
    case 'submitted':
      return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Submitted</Badge>;
    case 'in_review':
      return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">In Review</Badge>;
    case 'rejected':
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>;
    case 'cancelled':
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Cancelled</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
}

function getSLAStatusBadge(slaStatus: string) {
  switch (slaStatus) {
    case 'on_track':
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">On Track</Badge>;
    case 'at_risk':
      return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">At Risk</Badge>;
    case 'overdue':
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Overdue</Badge>;
    case 'completed_on_time':
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">On Time</Badge>;
    case 'completed_late':
      return <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-100">Late</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
}

function getPriorityBadge(priority: string) {
  switch (priority) {
    case 'urgent':
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Urgent</Badge>;
    case 'high':
      return <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-100">High</Badge>;
    case 'medium':
      return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Medium</Badge>;
    case 'low':
      return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Low</Badge>;
    default:
      return <Badge variant="secondary">Normal</Badge>;
  }
}

function calculateTimeRemaining(dueDate: string): { text: string; percentage: number; isOverdue: boolean } {
  const now = new Date();
  const due = new Date(dueDate);
  const diffMs = due.getTime() - now.getTime();
  const diffHours = diffMs / (1000 * 60 * 60);

  if (diffHours <= 0) {
    return { text: 'Overdue', percentage: 0, isOverdue: true };
  }

  if (diffHours < 24) {
    return {
      text: `${Math.ceil(diffHours)} hours left`,
      percentage: Math.max(0, Math.min(100, (diffHours / 24) * 100)),
      isOverdue: false
    };
  }

  const diffDays = Math.ceil(diffHours / 24);
  return {
    text: `${diffDays} days left`,
    percentage: Math.max(0, Math.min(100, (diffHours / (7 * 24)) * 100)),
    isOverdue: false
  };
}

export function RequestTracking() {
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitStatus, setSubmitStatus] = useState<{
    type: "success" | "error" | null;
    message: string;
  }>({ type: null, message: "" });

  const [requestForm, setRequestForm] = useState<RequestForm>({
    requesting_department: "",
    service_department: "",
    service_type: "",
    request_description: "",
    attached_files: [],
    submitted_by: "",
    priority: "medium"
  });

  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [departmentFilter, setDepartmentFilter] = useState("all");

  const { searchTerm } = useFilters();

  // Fetch requests on component mount
  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/requests');
      const data = await response.json();
      setRequests(data);
    } catch (error) {
      console.error('Error fetching requests:', error);
      setSubmitStatus({
        type: "error",
        message: "Failed to load requests"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitRequest = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      // Validate required fields
      if (!requestForm.requesting_department || !requestForm.service_type || !requestForm.request_description || !requestForm.submitted_by) {
        setSubmitStatus({
          type: "error",
          message: "Please fill in all required fields"
        });
        return;
      }

      // Auto-assign service department based on service type
      const serviceTypeInfo = SERVICE_TYPES[requestForm.service_type as keyof typeof SERVICE_TYPES];
      const finalForm = {
        ...requestForm,
        service_department: serviceTypeInfo?.department || requestForm.service_department
      };

      const response = await fetch('/api/requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(finalForm),
      });

      if (response.ok) {
        const newRequest = await response.json();
        setRequests(prev => [newRequest, ...prev]);

        // Reset form
        setRequestForm({
          requesting_department: "",
          service_department: "",
          service_type: "",
          request_description: "",
          attached_files: [],
          submitted_by: "",
          priority: "medium"
        });

        setSubmitStatus({
          type: "success",
          message: `Request ${newRequest.request_id} has been submitted successfully!`
        });

        // Clear success message after 3 seconds
        setTimeout(() => {
          setSubmitStatus({ type: null, message: "" });
        }, 3000);
      } else {
        const error = await response.json();
        setSubmitStatus({
          type: "error",
          message: error.error || "Failed to submit request"
        });
      }
    } catch (error) {
      setSubmitStatus({
        type: "error",
        message: "Network error. Please try again."
      });
    }
  };

  const handleStatusUpdate = async (requestId: string, newStatus: string) => {
    try {
      const response = await fetch('/api/requests', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          request_id: requestId,
          status: newStatus
        }),
      });

      if (response.ok) {
        const updatedRequest = await response.json();
        setRequests(prev =>
          prev.map(req =>
            req.request_id === requestId ? updatedRequest : req
          )
        );
      }
    } catch (error) {
      console.error('Error updating request status:', error);
    }
  };

  // Filter requests
  const filteredRequests = requests.filter(request => {
    const matchesSearch = !searchTerm ||
      request.request_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.request_description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.service_type.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === "all" || request.status === statusFilter;
    const matchesPriority = priorityFilter === "all" || request.priority === priorityFilter;
    const matchesDepartment = departmentFilter === "all" ||
      request.requesting_department === departmentFilter ||
      request.service_department === departmentFilter;

    return matchesSearch && matchesStatus && matchesPriority && matchesDepartment;
  });

  // Calculate statistics
  const stats = {
    total: requests.length,
    submitted: requests.filter(r => r.status === 'submitted').length,
    in_progress: requests.filter(r => r.status === 'in_progress').length,
    completed: requests.filter(r => r.status === 'completed').length,
    overdue: requests.filter(r => r.sla_status === 'overdue').length,
    on_track: requests.filter(r => r.sla_status === 'on_track').length
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Request Status Tracking</h2>
        <p className="text-gray-500">Submit and track internal service requests across departments</p>
      </div>

      {/* Status Messages */}
      {submitStatus.type && (
        <Alert className={submitStatus.type === "success" ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
          <AlertDescription className={submitStatus.type === "success" ? "text-green-800" : "text-red-800"}>
            {submitStatus.message}
          </AlertDescription>
        </Alert>
      )}

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
            <div className="text-sm text-gray-600">Total Requests</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-yellow-600">{stats.submitted}</div>
            <div className="text-sm text-gray-600">Submitted</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-600">{stats.in_progress}</div>
            <div className="text-sm text-gray-600">In Progress</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-600">{stats.completed}</div>
            <div className="text-sm text-gray-600">Completed</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-red-600">{stats.overdue}</div>
            <div className="text-sm text-gray-600">Overdue</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-600">{stats.on_track}</div>
            <div className="text-sm text-gray-600">On Track</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="requests" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="requests">View Requests</TabsTrigger>
          <TabsTrigger value="submit">Submit Request</TabsTrigger>
        </TabsList>

        <TabsContent value="requests" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Request Filters
                <Button variant="outline" size="sm" onClick={fetchRequests}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Refresh
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="status-filter">Status</Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="All Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="submitted">Submitted</SelectItem>
                      <SelectItem value="in_review">In Review</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="priority-filter">Priority</Label>
                  <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="All Priorities" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priorities</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="department-filter">Department</Label>
                  <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="All Departments" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Departments</SelectItem>
                      {DEPARTMENTS.map((dept) => (
                        <SelectItem key={dept} value={dept}>
                          {dept}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setStatusFilter("all");
                      setPriorityFilter("all");
                      setDepartmentFilter("all");
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Requests Table */}
          <Card>
            <CardHeader>
              <CardTitle>
                Requests ({filteredRequests.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">Loading requests...</div>
              ) : filteredRequests.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">No requests found</h3>
                  <p className="text-gray-500">Submit your first request or adjust your filters</p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Request ID</TableHead>
                        <TableHead>Service Type</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Priority</TableHead>
                        <TableHead>SLA Status</TableHead>
                        <TableHead>Time Remaining</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRequests.map((request) => {
                        const timeRemaining = calculateTimeRemaining(request.sla_due_date);

                        return (
                          <TableRow key={request.request_id}>
                            <TableCell>
                              <div className="flex items-center space-x-2">
                                {getStatusIcon(request.status)}
                                <div>
                                  <div className="font-medium">{request.request_id}</div>
                                  <div className="text-sm text-gray-500">
                                    by {request.submitted_by}
                                  </div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div>
                                <div className="font-medium">{request.service_type}</div>
                                <div className="text-sm text-gray-500">
                                  {request.expected_duration}h expected
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div>
                                <div className="text-sm font-medium">From: {request.requesting_department}</div>
                                <div className="text-sm text-gray-500">To: {request.service_department}</div>
                              </div>
                            </TableCell>
                            <TableCell>
                              {getStatusBadge(request.status)}
                            </TableCell>
                            <TableCell>
                              {getPriorityBadge(request.priority)}
                            </TableCell>
                            <TableCell>
                              {getSLAStatusBadge(request.sla_status)}
                            </TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className={`text-sm font-medium ${
                                  timeRemaining.isOverdue ? "text-red-600" : "text-green-600"
                                }`}>
                                  {timeRemaining.text}
                                </div>
                                <Progress
                                  value={timeRemaining.percentage}
                                  className={`h-2 ${timeRemaining.isOverdue ? "bg-red-100" : "bg-green-100"}`}
                                />
                              </div>
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" className="h-8 w-8 p-0">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => handleStatusUpdate(request.request_id, 'in_review')}>
                                    Mark In Review
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleStatusUpdate(request.request_id, 'approved')}>
                                    Approve
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleStatusUpdate(request.request_id, 'in_progress')}>
                                    Start Progress
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleStatusUpdate(request.request_id, 'completed')}>
                                    Mark Complete
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    onClick={() => handleStatusUpdate(request.request_id, 'rejected')}
                                    className="text-red-600"
                                  >
                                    Reject
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="submit" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Plus className="h-5 w-5" />
                <span>Submit New Request</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitRequest} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="requesting-department">Requesting Department *</Label>
                    <Select
                      value={requestForm.requesting_department}
                      onValueChange={(value) => setRequestForm({...requestForm, requesting_department: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select your department" />
                      </SelectTrigger>
                      <SelectContent>
                        {DEPARTMENTS.map((dept) => (
                          <SelectItem key={dept} value={dept}>
                            {dept}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="service-type">Service Type *</Label>
                    <Select
                      value={requestForm.service_type}
                      onValueChange={(value) => setRequestForm({...requestForm, service_type: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select service type" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(SERVICE_TYPES).map(([serviceType, info]) => (
                          <SelectItem key={serviceType} value={serviceType}>
                            {serviceType} ({info.duration}h - {info.department})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="submitted-by">Your Name *</Label>
                    <Input
                      id="submitted-by"
                      placeholder="e.g., John Doe"
                      value={requestForm.submitted_by}
                      onChange={(e) => setRequestForm({...requestForm, submitted_by: e.target.value})}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="priority">Priority Level</Label>
                    <Select
                      value={requestForm.priority}
                      onValueChange={(value) => setRequestForm({...requestForm, priority: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="request-description">Request Description *</Label>
                  <Textarea
                    id="request-description"
                    placeholder="Provide detailed description of your request..."
                    value={requestForm.request_description}
                    onChange={(e) => setRequestForm({...requestForm, request_description: e.target.value})}
                    rows={4}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="attached-files">Attached Files (Optional)</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                    <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500 mb-2">Drop files here or click to upload</p>
                    <Button type="button" variant="outline" size="sm">
                      Choose Files
                    </Button>
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Submit Request
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
