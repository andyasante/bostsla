"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

// Sample data for charts
const slaComplianceData = [
  { name: "Week 1", compliance: 99.5, target: 99.5 },
  { name: "Week 2", compliance: 99.2, target: 99.5 },
  { name: "Week 3", compliance: 99.8, target: 99.5 },
  { name: "Week 4", compliance: 99.1, target: 99.5 },
  { name: "Week 5", compliance: 99.3, target: 99.5 },
  { name: "Week 6", compliance: 99.6, target: 99.5 },
  { name: "Week 7", compliance: 99.2, target: 99.5 }
];

const responseTimeData = [
  { name: "00:00", it: 2.1, finance: 1.8, terminal: 2.5, trading: 3.2, procurement: 2.8 },
  { name: "04:00", it: 1.9, finance: 1.5, terminal: 2.1, trading: 2.8, procurement: 2.5 },
  { name: "08:00", it: 3.2, finance: 2.8, terminal: 3.5, trading: 4.1, procurement: 3.8 },
  { name: "12:00", it: 2.8, finance: 2.3, terminal: 3.1, trading: 3.7, procurement: 3.4 },
  { name: "16:00", it: 2.4, finance: 2.0, terminal: 2.7, trading: 3.3, procurement: 3.0 },
  { name: "20:00", it: 2.0, finance: 1.7, terminal: 2.3, trading: 2.9, procurement: 2.6 }
];

const incidentsByDepartment = [
  { name: "IT", incidents: 12, resolved: 10 },
  { name: "Finance", incidents: 8, resolved: 7 },
  { name: "Terminal & Transmissions", incidents: 15, resolved: 12 },
  { name: "Fuel Trading", incidents: 9, resolved: 8 },
  { name: "Procurement & Supply Chain", incidents: 7, resolved: 6 },
  { name: "Assets & Infrastructure", incidents: 11, resolved: 9 },
  { name: "HR & Administration", incidents: 5, resolved: 5 }
];

const serviceStatusDistribution = [
  { name: "Operational", value: 75, color: "#10b981" },
  { name: "Degraded", value: 15, color: "#f59e0b" },
  { name: "Outage", value: 5, color: "#ef4444" },
  { name: "Maintenance", value: 5, color: "#6b7280" }
];

const uptimeData = [
  { name: "Jan", uptime: 99.9 },
  { name: "Feb", uptime: 99.5 },
  { name: "Mar", uptime: 99.8 },
  { name: "Apr", uptime: 99.2 },
  { name: "May", uptime: 99.7 },
  { name: "Jun", uptime: 99.8 }
];

export function ChartsSection() {
  return (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="incidents">Incidents</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* SLA Compliance Chart */}
            <Card>
              <CardHeader>
                <CardTitle>SLA Compliance Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={slaComplianceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[98.5, 100]} />
                    <Tooltip />
                    <Legend />
                    <Area
                      type="monotone"
                      dataKey="compliance"
                      stackId="1"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.3}
                    />
                    <Line
                      type="monotone"
                      dataKey="target"
                      stroke="#ef4444"
                      strokeDasharray="5 5"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Service Status Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Service Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={serviceStatusDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {serviceStatusDistribution.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Response Time by Department */}
            <Card>
              <CardHeader>
                <CardTitle>Response Time by Department (24h)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={responseTimeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="it" stroke="#3b82f6" name="IT" />
                    <Line type="monotone" dataKey="finance" stroke="#10b981" name="Finance" />
                    <Line type="monotone" dataKey="terminal" stroke="#f59e0b" name="Terminal & Transmissions" />
                    <Line type="monotone" dataKey="trading" stroke="#ef4444" name="Fuel Trading" />
                    <Line type="monotone" dataKey="procurement" stroke="#8b5cf6" name="Procurement & Supply Chain" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Monthly Uptime */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Uptime (%)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={uptimeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[99, 100]} />
                    <Tooltip />
                    <Bar dataKey="uptime" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="incidents" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Incidents by Department</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={incidentsByDepartment} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={100} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="incidents" fill="#ef4444" name="Total Incidents" />
                  <Bar dataKey="resolved" fill="#10b981" name="Resolved" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                    <div className="p-4 bg-green-50 rounded-lg">
                      <h3 className="font-semibold text-green-800">Improving</h3>
                      <p className="text-2xl font-bold text-green-600">Response Time</p>
                      <p className="text-sm text-green-600">↓ 12% this month</p>
                    </div>
                    <div className="p-4 bg-yellow-50 rounded-lg">
                      <h3 className="font-semibold text-yellow-800">Stable</h3>
                      <p className="text-2xl font-bold text-yellow-600">SLA Compliance</p>
                      <p className="text-sm text-yellow-600">± 0.2% variance</p>
                    </div>
                    <div className="p-4 bg-red-50 rounded-lg">
                      <h3 className="font-semibold text-red-800">Needs Attention</h3>
                      <p className="text-2xl font-bold text-red-600">Ticket Backlog</p>
                      <p className="text-sm text-red-600">↑ 15% this week</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
