"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Bell, Settings, Search, Filter, RefreshCw, X } from "lucide-react";
import { useState } from "react";
import { useFilters } from "./filter-context";

export function DashboardHeader() {
  const [refreshing, setRefreshing] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const {
    searchTerm,
    selectedDepartment,
    selectedStatus,
    dateRange,
    priority,
    setSearchTerm,
    setSelectedDepartment,
    setSelectedStatus,
    setDateRange,
    setPriority,
    clearFilters,
  } = useFilters();

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  const hasActiveFilters = searchTerm || selectedDepartment !== "all" || selectedStatus !== "all" || dateRange !== "all" || priority !== "all";

  return (
    <header className="bg-white border-b shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Title */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">SLA</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">SLA Monitor</h1>
                <p className="text-sm text-gray-500">BOST Operations Dashboard</p>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="hidden md:flex items-center space-x-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">99.2%</p>
              <p className="text-xs text-gray-500">Overall SLA</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">12</p>
              <p className="text-xs text-gray-500">Active Services</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-red-600">3</p>
              <p className="text-xs text-gray-500">Active Alerts</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={refreshing}
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
            </Button>
            <Button variant="outline" size="sm">
              <Bell className="h-4 w-4" />
              <Badge className="ml-1 px-1 text-xs">3</Badge>
            </Button>
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center space-x-4 mt-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search services..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              <SelectItem value="md-secretariat">MD's Secretariat</SelectItem>
              <SelectItem value="corporate-planning">Corporate Planning</SelectItem>
              <SelectItem value="legal">Legal</SelectItem>
              <SelectItem value="finance">Finance</SelectItem>
              <SelectItem value="terminal-transmissions">Terminal & Transmissions</SelectItem>
              <SelectItem value="fuel-trading">Fuel Trading</SelectItem>
              <SelectItem value="it">IT</SelectItem>
              <SelectItem value="procurement-supply">Procurement & Supply Chain</SelectItem>
              <SelectItem value="audit">Audit</SelectItem>
              <SelectItem value="hr-admin">Human Resources & Administration</SelectItem>
              <SelectItem value="corporate-comms">Corporate Communications & External Affairs</SelectItem>
              <SelectItem value="assets-infrastructure">Assets & Infrastructure</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="operational">Operational</SelectItem>
              <SelectItem value="degraded">Degraded</SelectItem>
              <SelectItem value="outage">Outage</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem>
            </SelectContent>
          </Select>

          <Dialog open={showAdvancedFilters} onOpenChange={setShowAdvancedFilters}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className={hasActiveFilters ? "border-blue-500 bg-blue-50" : ""}>
                <Filter className="h-4 w-4 mr-2" />
                More Filters
                {hasActiveFilters && <Badge className="ml-2 px-1 text-xs">Active</Badge>}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Advanced Filters</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="date-range">Date Range</Label>
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select date range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Time</SelectItem>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="week">This Week</SelectItem>
                      <SelectItem value="month">This Month</SelectItem>
                      <SelectItem value="quarter">This Quarter</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="priority">Priority Level</Label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priorities</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex space-x-2 mt-6">
                  <Button variant="outline" onClick={clearFilters} className="flex-1">
                    <X className="h-4 w-4 mr-2" />
                    Clear All
                  </Button>
                  <Button onClick={() => setShowAdvancedFilters(false)} className="flex-1">
                    Apply Filters
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters} className="text-gray-500 hover:text-gray-700">
              <X className="h-4 w-4 mr-2" />
              Clear All Filters
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
