"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Database,
  CheckCircle,
  AlertTriangle,
  Loader2,
  Copy,
  Eye,
  EyeOff
} from "lucide-react";
import { useState } from "react";

interface DatabaseConfig {
  type: string;
  host: string;
  port: string;
  database: string;
  username: string;
  password: string;
  ssl: boolean;
}

interface ConnectionTest {
  status: "idle" | "testing" | "success" | "error";
  message: string;
}

export function DatabaseConnection() {
  const [config, setConfig] = useState<DatabaseConfig>({
    type: "postgresql",
    host: "localhost", // Default to localhost for host computer
    port: "5432",
    database: "bost_sla_monitoring",
    username: "",
    password: "",
    ssl: false
  });

  const [connectionTest, setConnectionTest] = useState<ConnectionTest>({
    status: "idle",
    message: ""
  });

  const [showPassword, setShowPassword] = useState(false);
  const [savedConnections, setSavedConnections] = useState<DatabaseConfig[]>([]);

  const databaseTypes = [
    { value: "postgresql", label: "PostgreSQL", defaultPort: "5432" },
    { value: "mysql", label: "MySQL", defaultPort: "3306" },
    { value: "mongodb", label: "MongoDB", defaultPort: "27017" },
    { value: "sqlserver", label: "SQL Server", defaultPort: "1433" },
    { value: "oracle", label: "Oracle", defaultPort: "1521" }
  ];

  const handleTypeChange = (type: string) => {
    const dbType = databaseTypes.find(db => db.value === type);
    setConfig({
      ...config,
      type,
      port: dbType?.defaultPort || "5432"
    });
  };

  const getHostIPInstructions = () => {
    return {
      windows: "Run 'ipconfig' in Command Prompt, look for IPv4 Address",
      mac: "Run 'ifconfig' in Terminal, look for inet address",
      linux: "Run 'ip addr show' or 'hostname -I' in Terminal"
    };
  };

  const testConnection = async () => {
    setConnectionTest({ status: "testing", message: "Testing connection..." });

    try {
      const response = await fetch('/api/database/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config),
      });

      const result = await response.json();

      if (result.success) {
        setConnectionTest({
          status: "success",
          message: result.message
        });

        // Add to saved connections if successful
        const newConnection = { ...config };
        setSavedConnections(prev => {
          const existing = prev.find(conn =>
            conn.host === newConnection.host &&
            conn.port === newConnection.port &&
            conn.database === newConnection.database
          );
          if (existing) return prev;
          return [...prev, newConnection];
        });
      } else {
        setConnectionTest({
          status: "error",
          message: result.error || "Connection test failed"
        });
      }
    } catch (error) {
      setConnectionTest({
        status: "error",
        message: error instanceof Error ? error.message : "Network error occurred"
      });
    }
  };

  const generateConnectionString = () => {
    const { type, host, port, database, username } = config;
    switch (type) {
      case "postgresql":
        return `postgresql://${username}:***@${host}:${port}/${database}`;
      case "mysql":
        return `mysql://${username}:***@${host}:${port}/${database}`;
      case "mongodb":
        return `mongodb://${username}:***@${host}:${port}/${database}`;
      default:
        return `${type}://${username}:***@${host}:${port}/${database}`;
    }
  };

  const copyConnectionString = () => {
    navigator.clipboard.writeText(generateConnectionString());
  };

  const saveConnection = async () => {
    try {
      const response = await fetch('/api/database/connect', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...config,
          connectionId: 'main'
        }),
      });

      const result = await response.json();

      if (result.success) {
        setConnectionTest({
          status: "success",
          message: `Database connection established and saved! ${result.message}`
        });
      } else {
        setConnectionTest({
          status: "error",
          message: result.error || "Failed to establish connection"
        });
      }
    } catch (error) {
      setConnectionTest({
        status: "error",
        message: error instanceof Error ? error.message : "Failed to save connection"
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Host Computer Setup Instructions */}
      <Alert>
        <Database className="h-4 w-4" />
        <AlertDescription>
          <div className="space-y-2">
            <p className="font-medium">Connect to Your Host Computer Database:</p>
            <div className="text-sm space-y-1">
              <p>• <strong>Find your host IP:</strong></p>
              <ul className="ml-4 space-y-1">
                <li>Windows: <code className="bg-gray-100 px-1 rounded">ipconfig</code></li>
                <li>Mac/Linux: <code className="bg-gray-100 px-1 rounded">ifconfig</code> or <code className="bg-gray-100 px-1 rounded">hostname -I</code></li>
              </ul>
              <p>• <strong>Configure database:</strong> Allow connections from Docker containers (bind to 0.0.0.0 or your IP)</p>
              <p>• <strong>Firewall:</strong> Ensure database port is accessible</p>
            </div>
          </div>
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>Database Connection Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Database Type */}
          <div>
            <Label htmlFor="db-type">Database Type</Label>
            <Select value={config.type} onValueChange={handleTypeChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {databaseTypes.map((db) => (
                  <SelectItem key={db.value} value={db.value}>
                    {db.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Host and Port */}
          <div className="grid grid-cols-3 gap-4">
            <div className="col-span-2">
              <Label htmlFor="host">Host (Your Computer's IP)</Label>
              <Input
                id="host"
                placeholder="192.168.1.100 or localhost"
                value={config.host}
                onChange={(e) => setConfig({...config, host: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="port">Port</Label>
              <Input
                id="port"
                placeholder="5432"
                value={config.port}
                onChange={(e) => setConfig({...config, port: e.target.value})}
              />
            </div>
          </div>

          {/* Database Name */}
          <div>
            <Label htmlFor="database">Database Name</Label>
            <Input
              id="database"
              placeholder="bost_sla_monitoring"
              value={config.database}
              onChange={(e) => setConfig({...config, database: e.target.value})}
            />
          </div>

          {/* Credentials */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                placeholder="postgres"
                value={config.username}
                onChange={(e) => setConfig({...config, username: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={config.password}
                  onChange={(e) => setConfig({...config, password: e.target.value})}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </div>

          {/* Connection String */}
          <div>
            <Label>Connection String Preview</Label>
            <div className="flex items-center space-x-2">
              <Input
                value={generateConnectionString()}
                readOnly
                className="font-mono text-sm"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={copyConnectionString}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Test Connection */}
          <div className="space-y-2">
            <Button
              onClick={testConnection}
              disabled={connectionTest.status === "testing"}
              className="w-full"
            >
              {connectionTest.status === "testing" && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Test Connection
            </Button>

            {connectionTest.status !== "idle" && (
              <Alert className={
                connectionTest.status === "success" ? "border-green-200 bg-green-50" :
                connectionTest.status === "error" ? "border-red-200 bg-red-50" : ""
              }>
                {connectionTest.status === "success" && <CheckCircle className="h-4 w-4 text-green-600" />}
                {connectionTest.status === "error" && <AlertTriangle className="h-4 w-4 text-red-600" />}
                {connectionTest.status === "testing" && <Loader2 className="h-4 w-4 animate-spin" />}
                <AlertDescription>{connectionTest.message}</AlertDescription>
              </Alert>
            )}
          </div>

          {/* Save Connection */}
          {connectionTest.status === "success" && (
            <Button variant="outline" className="w-full" onClick={saveConnection}>
              Save & Establish Connection
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Saved Connections */}
      {savedConnections.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Saved Connections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {savedConnections.map((conn, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">{conn.database}</div>
                    <div className="text-sm text-gray-500">
                      {conn.type.toUpperCase()} • {conn.host}:{conn.port}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Badge className="bg-green-100 text-green-800">Connected</Badge>
                    <Button variant="outline" size="sm">
                      Use
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Database Setup Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Database Setup Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm">
            <div>
              <h4 className="font-medium mb-2">1. Create Database Tables:</h4>
              <div className="bg-gray-100 p-3 rounded font-mono text-xs">
{`CREATE TABLE services (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  department VARCHAR(100),
  endpoint VARCHAR(500),
  status VARCHAR(50) DEFAULT 'operational',
  sla_target DECIMAL(5,2),
  response_time_target INTEGER,
  priority VARCHAR(20),
  monitoring_enabled BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE incidents (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  severity VARCHAR(20),
  department VARCHAR(100),
  status VARCHAR(50),
  assignee VARCHAR(100),
  affected_services TEXT[],
  created_at TIMESTAMP DEFAULT NOW()
);`}
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-2">2. Configure Database Access:</h4>
              <ul className="space-y-1 ml-4">
                <li>• Edit postgresql.conf: <code>listen_addresses = '*'</code></li>
                <li>• Edit pg_hba.conf: Add your Docker network range</li>
                <li>• Restart database service</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
