"use client";

import { createContext, useContext, useState, type ReactNode } from "react";

interface FilterContextType {
  searchTerm: string;
  selectedDepartment: string;
  selectedStatus: string;
  dateRange: string;
  priority: string;
  setSearchTerm: (term: string) => void;
  setSelectedDepartment: (dept: string) => void;
  setSelectedStatus: (status: string) => void;
  setDateRange: (range: string) => void;
  setPriority: (priority: string) => void;
  clearFilters: () => void;
}

const FilterContext = createContext<FilterContextType | undefined>(undefined);

export function FilterProvider({ children }: { children: ReactNode }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [dateRange, setDateRange] = useState("all");
  const [priority, setPriority] = useState("all");

  const clearFilters = () => {
    setSearchTerm("");
    setSelectedDepartment("all");
    setSelectedStatus("all");
    setDateRange("all");
    setPriority("all");
  };

  return (
    <FilterContext.Provider
      value={{
        searchTerm,
        selectedDepartment,
        selectedStatus,
        dateRange,
        priority,
        setSearchTerm,
        setSelectedDepartment,
        setSelectedStatus,
        setDateRange,
        setPriority,
        clearFilters,
      }}
    >
      {children}
    </FilterContext.Provider>
  );
}

export function useFilters() {
  const context = useContext(FilterContext);
  if (context === undefined) {
    throw new Error("useFilters must be used within a FilterProvider");
  }
  return context;
}
