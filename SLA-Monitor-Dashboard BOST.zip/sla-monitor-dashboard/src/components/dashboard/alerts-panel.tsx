"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useFilters } from "./filter-context";
import {
  AlertTriangle,
  XCircle,
  Clock,
  Bell,
  X,
  ExternalLink,
  CheckCircle
} from "lucide-react";
import { useState } from "react";

const alertsData = [
  {
    id: "alert-001",
    title: "Asset Management System Outage",
    description: "Asset Management System is completely unavailable. Database connection failed.",
    severity: "critical",
    department: "Assets & Infrastructure",
    timestamp: "30 minutes ago",
    status: "active",
    affectedServices: ["Asset Management System", "Infrastructure Monitoring"],
    assignee: "John Smith"
  },
  {
    id: "alert-002",
    title: "High Response Time - Terminal Operations",
    description: "Terminal Operations Management system response time exceeding 3 seconds consistently.",
    severity: "warning",
    department: "Terminal & Transmissions",
    timestamp: "2 hours ago",
    status: "investigating",
    affectedServices: ["Terminal Operations Management"],
    assignee: "Sarah Johnson"
  },
  {
    id: "alert-003",
    title: "Scheduled Maintenance - Procurement System",
    description: "Planned maintenance window for Procurement & Supply Chain System database upgrade.",
    severity: "info",
    department: "Procurement & Supply Chain",
    timestamp: "4 hours ago",
    status: "scheduled",
    affectedServices: ["Procurement & Supply Chain System"],
    assignee: "Mike Wilson"
  },
  {
    id: "alert-004",
    title: "SLA Breach Warning - Finance System",
    description: "Financial Management System approaching SLA threshold (98.5%).",
    severity: "warning",
    department: "Finance",
    timestamp: "1 day ago",
    status: "monitoring",
    affectedServices: ["Financial Management System"],
    assignee: "Lisa Chen"
  },
  {
    id: "alert-005",
    title: "SSL Certificate Expiring",
    description: "SSL certificate for BOST Employee Portal expires in 7 days.",
    severity: "warning",
    department: "IT",
    timestamp: "2 days ago",
    status: "scheduled",
    affectedServices: ["BOST Employee Portal"],
    assignee: "David Brown"
  }
];

function getSeverityIcon(severity: string) {
  switch (severity) {
    case "critical":
      return <XCircle className="h-4 w-4 text-red-600" />;
    case "warning":
      return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
    case "info":
      return <Bell className="h-4 w-4 text-blue-600" />;
    default:
      return <Bell className="h-4 w-4 text-gray-600" />;
  }
}

function getSeverityBadge(severity: string) {
  switch (severity) {
    case "critical":
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Critical</Badge>;
    case "warning":
      return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Warning</Badge>;
    case "info":
      return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Info</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
}

function getStatusBadge(status: string) {
  switch (status) {
    case "active":
      return <Badge variant="destructive">Active</Badge>;
    case "investigating":
      return <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-100">Investigating</Badge>;
    case "monitoring":
      return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">Monitoring</Badge>;
    case "scheduled":
      return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Scheduled</Badge>;
    case "resolved":
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Resolved</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
}

export function AlertsPanel() {
  const [alerts, setAlerts] = useState(alertsData);
  const [filter, setFilter] = useState("all");
  const { searchTerm, selectedDepartment } = useFilters();

  const dismissAlert = (alertId: string) => {
    setAlerts(alerts.filter(alert => alert.id !== alertId));
  };

  // Apply both severity filter and global filters
  const filteredAlerts = alerts.filter(alert => {
    const matchesSeverity = filter === "all" || alert.severity === filter;

    const matchesSearch = !searchTerm ||
      alert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.affectedServices.some(service =>
        service.toLowerCase().includes(searchTerm.toLowerCase())
      );

    const matchesDepartment = selectedDepartment === "all" ||
      alert.department.toLowerCase().includes(selectedDepartment.replace("-", " "));

    return matchesSeverity && matchesSearch && matchesDepartment;
  });

  const criticalCount = alerts.filter(a => a.severity === "critical").length;
  const warningCount = alerts.filter(a => a.severity === "warning").length;
  const infoCount = alerts.filter(a => a.severity === "info").length;

  return (
    <div className="space-y-4">
      {/* Alert Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Alert Summary
            <div className="flex space-x-1">
              <Button
                variant={filter === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("all")}
              >
                All ({alerts.length})
              </Button>
              <Button
                variant={filter === "critical" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("critical")}
                className="text-red-600"
              >
                {criticalCount}
              </Button>
              <Button
                variant={filter === "warning" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("warning")}
                className="text-yellow-600"
              >
                {warningCount}
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="p-3 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{criticalCount}</div>
              <div className="text-sm text-red-600">Critical</div>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">{warningCount}</div>
              <div className="text-sm text-yellow-600">Warning</div>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{infoCount}</div>
              <div className="text-sm text-blue-600">Info</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Active Alerts
            <Button variant="outline" size="sm">
              <Bell className="h-4 w-4 mr-2" />
              Manage Alerts
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredAlerts.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-2" />
                <h3 className="text-lg font-medium text-gray-900">No alerts</h3>
                <p className="text-gray-500">
                  {filter === "all" ? "All systems are operating normally" : `No ${filter} alerts at this time`}
                </p>
              </div>
            ) : (
              filteredAlerts.map((alert) => (
                <Alert key={alert.id} className="relative">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 mt-0.5">
                      {getSeverityIcon(alert.severity)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium text-gray-900">
                          {alert.title}
                        </h4>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0"
                          onClick={() => dismissAlert(alert.id)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                      <AlertDescription className="text-sm text-gray-600 mb-2">
                        {alert.description}
                      </AlertDescription>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {getSeverityBadge(alert.severity)}
                          {getStatusBadge(alert.status)}
                          <Badge variant="outline">{alert.department}</Badge>
                        </div>
                        <div className="text-xs text-gray-500">
                          {alert.timestamp}
                        </div>
                      </div>
                      <div className="mt-2 text-xs text-gray-500">
                        <div>Assigned to: <span className="font-medium">{alert.assignee}</span></div>
                        <div>Affected: {alert.affectedServices.join(", ")}</div>
                      </div>
                      <div className="flex space-x-2 mt-3">
                        <Button variant="outline" size="sm">
                          <ExternalLink className="h-3 w-3 mr-1" />
                          View Details
                        </Button>
                        {alert.status === "active" && (
                          <Button variant="outline" size="sm">
                            Acknowledge
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </Alert>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Button variant="outline" className="w-full justify-start">
              <Bell className="h-4 w-4 mr-2" />
              Create New Alert
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Clock className="h-4 w-4 mr-2" />
              Schedule Maintenance
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <ExternalLink className="h-4 w-4 mr-2" />
              View Alert History
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
