"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Clock,
  CheckCircle,
  AlertTriangle,
  Timer,
  TrendingUp,
  TrendingDown,
  Activity
} from "lucide-react";

const kpiData = [
  {
    title: "Overall SLA Compliance",
    value: "99.2%",
    target: 99.5,
    actual: 99.2,
    trend: -0.3,
    icon: CheckCircle,
    status: "warning"
  },
  {
    title: "Average Response Time",
    value: "2.4min",
    target: "< 3min",
    actual: 2.4,
    trend: +0.2,
    icon: Clock,
    status: "success"
  },
  {
    title: "Average Resolution Time",
    value: "45.2min",
    target: "< 60min",
    actual: 45.2,
    trend: -5.1,
    icon: Timer,
    status: "success"
  },
  {
    title: "System Uptime",
    value: "99.8%",
    target: 99.9,
    actual: 99.8,
    trend: +0.1,
    icon: Activity,
    status: "success"
  },
  {
    title: "Critical Incidents",
    value: "3",
    target: "< 5",
    actual: 3,
    trend: +1,
    icon: AlertTriangle,
    status: "success"
  },
  {
    title: "Ticket Backlog",
    value: "127",
    target: "< 100",
    actual: 127,
    trend: +15,
    icon: TrendingUp,
    status: "warning"
  }
];

function getStatusColor(status: string) {
  switch (status) {
    case "success": return "text-green-600";
    case "warning": return "text-yellow-600";
    case "danger": return "text-red-600";
    default: return "text-gray-600";
  }
}

function getTrendIcon(trend: number) {
  return trend > 0 ? TrendingUp : TrendingDown;
}

function getTrendColor(trend: number, inverse = false) {
  const isPositive = inverse ? trend < 0 : trend > 0;
  return isPositive ? "text-green-600" : "text-red-600";
}

export function KPICards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {kpiData.map((kpi) => {
        const Icon = kpi.icon;
        const TrendIcon = getTrendIcon(kpi.trend);
        const isPercentage = typeof kpi.actual === "number" && kpi.actual < 100;

        return (
          <Card key={kpi.title} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {kpi.title}
              </CardTitle>
              <Icon className={`h-4 w-4 ${getStatusColor(kpi.status)}`} />
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-2">
                <div className="text-2xl font-bold">{kpi.value}</div>
                <Badge variant={kpi.status === "success" ? "default" : kpi.status === "warning" ? "secondary" : "destructive"}>
                  {kpi.status}
                </Badge>
              </div>

              <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                <span>Target: {kpi.target}</span>
                <div className={`flex items-center ${getTrendColor(kpi.trend, kpi.title.includes("Critical") || kpi.title.includes("Backlog"))}`}>
                  <TrendIcon className="h-3 w-3 mr-1" />
                  <span>{Math.abs(kpi.trend)}{isPercentage ? "%" : ""}</span>
                </div>
              </div>

              {/* Progress bar for percentage values */}
              {isPercentage && (
                <div className="space-y-1">
                  <Progress value={kpi.actual} className="h-2" />
                  <div className="flex justify-between text-xs text-gray-400">
                    <span>0%</span>
                    <span>100%</span>
                  </div>
                </div>
              )}

              {/* Additional context */}
              {kpi.title === "Overall SLA Compliance" && (
                <p className="text-xs text-gray-500 mt-2">
                  Based on 12 active services across all departments
                </p>
              )}

              {kpi.title === "Critical Incidents" && (
                <p className="text-xs text-gray-500 mt-2">
                  2 resolved this week, 1 in progress
                </p>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
