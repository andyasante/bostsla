import { type NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/database';

interface Incident {
  id?: number;
  incident_id: string;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  department: string;
  status: 'open' | 'investigating' | 'resolved' | 'closed';
  assignee: string;
  affected_services: string[];
  estimated_resolution?: string;
}

// GET /api/incidents - Fetch all incidents
export async function GET(request: NextRequest) {
  try {
    const connection = db.getConnection('main');
    if (!connection) {
      // Return default incidents if no database connection
      return NextResponse.json([
        {
          incident_id: "inc-001",
          title: "Asset Management System Outage",
          description: "Asset Management System is completely unavailable. Database connection failed.",
          severity: "critical",
          department: "Assets & Infrastructure",
          status: "open",
          assignee: "John Smith",
          affected_services: ["Asset Management System", "Infrastructure Monitoring"],
          created_at: new Date().toISOString()
        },
        {
          incident_id: "inc-002",
          title: "High Response Time - Terminal Operations",
          description: "Terminal Operations Management system response time exceeding 3 seconds consistently.",
          severity: "medium",
          department: "Terminal & Transmissions",
          status: "investigating",
          assignee: "Sarah Johnson",
          affected_services: ["Terminal Operations Management"],
          created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
        }
      ]);
    }

    const incidents = await connection.query(`
      SELECT * FROM incidents
      ORDER BY created_at DESC
    `);

    return NextResponse.json(incidents);
  } catch (error) {
    console.error('Error fetching incidents:', error);
    return NextResponse.json(
      { error: 'Failed to fetch incidents' },
      { status: 500 }
    );
  }
}

// POST /api/incidents - Create new incident
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      title,
      description,
      severity,
      department,
      assignee,
      affected_services,
      estimated_resolution
    } = body;

    // Validate required fields
    if (!title || !description || !severity) {
      return NextResponse.json(
        { error: 'Title, description, and severity are required' },
        { status: 400 }
      );
    }

    const incident_id = `inc-${Date.now().toString().slice(-6)}`;

    const connection = db.getConnection('main');
    if (!connection) {
      // Return success even without database for demo purposes
      return NextResponse.json({
        incident_id,
        title,
        description,
        severity,
        department,
        status: 'open',
        assignee: assignee || 'Unassigned',
        affected_services: affected_services || [],
        estimated_resolution,
        created_at: new Date().toISOString()
      });
    }

    const result = await connection.query(`
      INSERT INTO incidents (
        incident_id, title, description, severity, department,
        status, assignee, affected_services, estimated_resolution
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *
    `, [
      incident_id,
      title,
      description,
      severity,
      department,
      'open',
      assignee || 'Unassigned',
      affected_services || [],
      estimated_resolution
    ]);

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error('Error creating incident:', error);
    return NextResponse.json(
      { error: 'Failed to create incident' },
      { status: 500 }
    );
  }
}

// PUT /api/incidents - Update incident
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { incident_id, ...updates } = body;

    if (!incident_id) {
      return NextResponse.json(
        { error: 'Incident ID is required' },
        { status: 400 }
      );
    }

    const connection = db.getConnection('main');
    if (!connection) {
      return NextResponse.json({ success: true, updates });
    }

    const setClause = Object.keys(updates)
      .map((key, index) => `${key} = $${index + 2}`)
      .join(', ');

    const result = await connection.query(`
      UPDATE incidents
      SET ${setClause}, updated_at = CURRENT_TIMESTAMP
      WHERE incident_id = $1
      RETURNING *
    `, [incident_id, ...Object.values(updates)]);

    if (result.length === 0) {
      return NextResponse.json(
        { error: 'Incident not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error('Error updating incident:', error);
    return NextResponse.json(
      { error: 'Failed to update incident' },
      { status: 500 }
    );
  }
}

// DELETE /api/incidents - Delete incident
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const incident_id = searchParams.get('incident_id');

    if (!incident_id) {
      return NextResponse.json(
        { error: 'Incident ID is required' },
        { status: 400 }
      );
    }

    const connection = db.getConnection('main');
    if (!connection) {
      return NextResponse.json({ success: true });
    }

    const result = await connection.query(
      'DELETE FROM incidents WHERE incident_id = $1 RETURNING *',
      [incident_id]
    );

    if (result.length === 0) {
      return NextResponse.json(
        { error: 'Incident not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting incident:', error);
    return NextResponse.json(
      { error: 'Failed to delete incident' },
      { status: 500 }
    );
  }
}
