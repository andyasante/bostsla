import { type NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/database';

interface Metric {
  id?: number;
  service_id: string;
  metric_type: 'uptime' | 'response_time' | 'sla_compliance' | 'error_rate' | 'throughput';
  value: number;
  unit: string;
  timestamp?: string;
}

// GET /api/metrics - Fetch metrics data
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const service_id = searchParams.get('service_id');
    const metric_type = searchParams.get('metric_type');
    const timeframe = searchParams.get('timeframe') || '24h';

    const connection = db.getConnection('main');
    if (!connection) {
      // Return mock metrics data
      return NextResponse.json(generateMockMetrics(service_id, metric_type, timeframe));
    }

    let query = 'SELECT * FROM metrics WHERE 1=1';
    const params: any[] = [];
    let paramIndex = 1;

    if (service_id) {
      query += ` AND service_id = $${paramIndex}`;
      params.push(service_id);
      paramIndex++;
    }

    if (metric_type) {
      query += ` AND metric_type = $${paramIndex}`;
      params.push(metric_type);
      paramIndex++;
    }

    // Add timeframe filter
    switch (timeframe) {
      case '1h':
        query += ` AND timestamp >= NOW() - INTERVAL '1 hour'`;
        break;
      case '24h':
        query += ` AND timestamp >= NOW() - INTERVAL '24 hours'`;
        break;
      case '7d':
        query += ` AND timestamp >= NOW() - INTERVAL '7 days'`;
        break;
      case '30d':
        query += ` AND timestamp >= NOW() - INTERVAL '30 days'`;
        break;
    }

    query += ' ORDER BY timestamp DESC LIMIT 1000';

    const metrics = await connection.query(query, params);
    return NextResponse.json(metrics);
  } catch (error) {
    console.error('Error fetching metrics:', error);
    return NextResponse.json(
      { error: 'Failed to fetch metrics' },
      { status: 500 }
    );
  }
}

// POST /api/metrics - Record new metric
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { service_id, metric_type, value, unit } = body;

    // Validate required fields
    if (!service_id || !metric_type || value === undefined) {
      return NextResponse.json(
        { error: 'Service ID, metric type, and value are required' },
        { status: 400 }
      );
    }

    const connection = db.getConnection('main');
    if (!connection) {
      // Return success even without database for demo purposes
      return NextResponse.json({
        service_id,
        metric_type,
        value,
        unit,
        timestamp: new Date().toISOString()
      });
    }

    const result = await connection.query(`
      INSERT INTO metrics (service_id, metric_type, value, unit)
      VALUES ($1, $2, $3, $4)
      RETURNING *
    `, [service_id, metric_type, value, unit || '']);

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error('Error recording metric:', error);
    return NextResponse.json(
      { error: 'Failed to record metric' },
      { status: 500 }
    );
  }
}

// GET /api/metrics/dashboard - Get dashboard summary metrics
export async function GET_SUMMARY(request: NextRequest) {
  try {
    const connection = db.getConnection('main');
    if (!connection) {
      // Return mock dashboard metrics
      return NextResponse.json({
        overall_sla: 99.2,
        avg_response_time: 2.4,
        avg_resolution_time: 45.2,
        system_uptime: 99.8,
        critical_incidents: 3,
        ticket_backlog: 127,
        services_count: {
          total: 12,
          operational: 9,
          degraded: 1,
          outage: 1,
          maintenance: 1
        },
        alerts_count: {
          total: 5,
          critical: 1,
          warning: 3,
          info: 1
        }
      });
    }

    // Calculate real-time dashboard metrics
    const [slaMetrics, responseMetrics, uptimeMetrics, servicesCounts, alertsCounts] = await Promise.all([
      connection.query(`
        SELECT AVG(sla_compliance) as avg_sla
        FROM services
        WHERE monitoring_enabled = true
      `),
      connection.query(`
        SELECT AVG(
          CASE
            WHEN response_time = 'N/A' THEN NULL
            ELSE CAST(REPLACE(response_time, 's', '') AS DECIMAL)
          END
        ) as avg_response_time
        FROM services
        WHERE monitoring_enabled = true
      `),
      connection.query(`
        SELECT AVG(uptime) as avg_uptime
        FROM services
        WHERE monitoring_enabled = true
      `),
      connection.query(`
        SELECT
          COUNT(*) as total,
          COUNT(CASE WHEN status = 'operational' THEN 1 END) as operational,
          COUNT(CASE WHEN status = 'degraded' THEN 1 END) as degraded,
          COUNT(CASE WHEN status = 'outage' THEN 1 END) as outage,
          COUNT(CASE WHEN status = 'maintenance' THEN 1 END) as maintenance
        FROM services
      `),
      connection.query(`
        SELECT
          COUNT(*) as total,
          COUNT(CASE WHEN severity = 'critical' THEN 1 END) as critical,
          COUNT(CASE WHEN severity = 'warning' THEN 1 END) as warning,
          COUNT(CASE WHEN severity = 'info' THEN 1 END) as info
        FROM alerts
        WHERE status != 'resolved'
      `)
    ]);

    return NextResponse.json({
      overall_sla: slaMetrics[0]?.avg_sla || 99.2,
      avg_response_time: responseMetrics[0]?.avg_response_time || 2.4,
      avg_resolution_time: 45.2, // This would need a separate calculation
      system_uptime: uptimeMetrics[0]?.avg_uptime || 99.8,
      critical_incidents: 3, // This would need incident tracking
      ticket_backlog: 127, // This would need ticket system integration
      services_count: servicesCounts[0] || { total: 0, operational: 0, degraded: 0, outage: 0, maintenance: 0 },
      alerts_count: alertsCounts[0] || { total: 0, critical: 0, warning: 0, info: 0 }
    });
  } catch (error) {
    console.error('Error fetching dashboard metrics:', error);
    return NextResponse.json(
      { error: 'Failed to fetch dashboard metrics' },
      { status: 500 }
    );
  }
}

// Helper function to generate mock metrics data
function generateMockMetrics(service_id?: string | null, metric_type?: string | null, timeframe = '24h') {
  const hours = timeframe === '1h' ? 1 : timeframe === '24h' ? 24 : timeframe === '7d' ? 168 : 720;
  const interval = hours <= 24 ? 60 : hours <= 168 ? 360 : 1440; // minutes between data points

  const metrics: any[] = [];
  const now = new Date();

  for (let i = 0; i < hours * 60; i += interval) {
    const timestamp = new Date(now.getTime() - i * 60 * 1000);

    if (metric_type === 'uptime' || !metric_type) {
      metrics.push({
        service_id: service_id || 'srv-001',
        metric_type: 'uptime',
        value: 98.5 + Math.random() * 1.5,
        unit: '%',
        timestamp: timestamp.toISOString()
      });
    }

    if (metric_type === 'response_time' || !metric_type) {
      metrics.push({
        service_id: service_id || 'srv-001',
        metric_type: 'response_time',
        value: 1.5 + Math.random() * 2,
        unit: 'seconds',
        timestamp: timestamp.toISOString()
      });
    }

    if (metric_type === 'sla_compliance' || !metric_type) {
      metrics.push({
        service_id: service_id || 'srv-001',
        metric_type: 'sla_compliance',
        value: 98 + Math.random() * 2,
        unit: '%',
        timestamp: timestamp.toISOString()
      });
    }
  }

  return metrics.reverse(); // Return in chronological order
}
