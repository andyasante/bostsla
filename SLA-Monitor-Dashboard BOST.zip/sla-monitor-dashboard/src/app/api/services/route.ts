import { type NextRequest, NextResponse } from 'next/server';
import { db, DatabaseConnection } from '@/lib/database';

interface Service {
  id?: number;
  service_id: string;
  name: string;
  department: string;
  endpoint: string;
  status: 'operational' | 'degraded' | 'outage' | 'maintenance';
  uptime: number;
  response_time: string;
  sla_compliance: number;
  sla_target: number;
  response_time_target: number;
  priority: string;
  monitoring_enabled: boolean;
  last_incident: string;
}

// GET /api/services - Fetch all services
export async function GET(request: NextRequest) {
  try {
    const connection = db.getConnection('main');
    if (!connection) {
      // Return default services if no database connection
      return NextResponse.json([
        {
          service_id: "srv-001",
          name: "BOST Employee Portal",
          department: "Human Resources & Administration",
          status: "operational",
          uptime: 99.8,
          response_time: "1.2s",
          sla_compliance: 99.5,
          sla_target: 99.5,
          response_time_target: 3,
          priority: "high",
          monitoring_enabled: true,
          last_incident: "3 days ago",
          endpoint: "/hr/portal"
        },
        {
          service_id: "srv-002",
          name: "Financial Management System",
          department: "Finance",
          status: "operational",
          uptime: 99.9,
          response_time: "0.8s",
          sla_compliance: 99.8,
          sla_target: 99.5,
          response_time_target: 2,
          priority: "critical",
          monitoring_enabled: true,
          last_incident: "1 week ago",
          endpoint: "/finance/fms"
        }
      ]);
    }

    const services = await connection.query(`
      SELECT * FROM services
      ORDER BY created_at DESC
    `);

    return NextResponse.json(services);
  } catch (error) {
    console.error('Error fetching services:', error);
    return NextResponse.json(
      { error: 'Failed to fetch services' },
      { status: 500 }
    );
  }
}

// POST /api/services - Create new service
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      name,
      department,
      endpoint,
      sla_target,
      response_time_target,
      priority,
      monitoring_enabled
    } = body;

    // Validate required fields
    if (!name || !department) {
      return NextResponse.json(
        { error: 'Name and department are required' },
        { status: 400 }
      );
    }

    const service_id = `srv-${Date.now().toString().slice(-6)}`;

    const connection = db.getConnection('main');
    if (!connection) {
      // Return success even without database for demo purposes
      return NextResponse.json({
        service_id,
        name,
        department,
        endpoint: endpoint || `/api/${name.toLowerCase().replace(/\s+/g, '-')}`,
        status: 'operational',
        uptime: 100.0,
        response_time: 'N/A',
        sla_compliance: sla_target || 99.0,
        sla_target: sla_target || 99.0,
        response_time_target: response_time_target || 3,
        priority: priority || 'medium',
        monitoring_enabled: monitoring_enabled !== false,
        last_incident: 'Never'
      });
    }

    const result = await connection.query(`
      INSERT INTO services (
        service_id, name, department, endpoint, sla_target,
        response_time_target, priority, monitoring_enabled,
        status, uptime, sla_compliance, last_incident
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `, [
      service_id,
      name,
      department,
      endpoint || `/api/${name.toLowerCase().replace(/\s+/g, '-')}`,
      sla_target || 99.0,
      response_time_target || 3,
      priority || 'medium',
      monitoring_enabled !== false,
      'operational',
      100.0,
      sla_target || 99.0,
      'Never'
    ]);

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error('Error creating service:', error);
    return NextResponse.json(
      { error: 'Failed to create service' },
      { status: 500 }
    );
  }
}

// PUT /api/services - Update service
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { service_id, ...updates } = body;

    if (!service_id) {
      return NextResponse.json(
        { error: 'Service ID is required' },
        { status: 400 }
      );
    }

    const connection = db.getConnection('main');
    if (!connection) {
      return NextResponse.json({ success: true, updates });
    }

    const setClause = Object.keys(updates)
      .map((key, index) => `${key} = $${index + 2}`)
      .join(', ');

    const result = await connection.query(`
      UPDATE services
      SET ${setClause}, updated_at = CURRENT_TIMESTAMP
      WHERE service_id = $1
      RETURNING *
    `, [service_id, ...Object.values(updates)]);

    if (result.length === 0) {
      return NextResponse.json(
        { error: 'Service not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error('Error updating service:', error);
    return NextResponse.json(
      { error: 'Failed to update service' },
      { status: 500 }
    );
  }
}

// DELETE /api/services - Delete service
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const service_id = searchParams.get('service_id');

    if (!service_id) {
      return NextResponse.json(
        { error: 'Service ID is required' },
        { status: 400 }
      );
    }

    const connection = db.getConnection('main');
    if (!connection) {
      return NextResponse.json({ success: true });
    }

    const result = await connection.query(
      'DELETE FROM services WHERE service_id = $1 RETURNING *',
      [service_id]
    );

    if (result.length === 0) {
      return NextResponse.json(
        { error: 'Service not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting service:', error);
    return NextResponse.json(
      { error: 'Failed to delete service' },
      { status: 500 }
    );
  }
}
