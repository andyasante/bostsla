import { type NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/database';

interface Request {
  id?: number;
  request_id: string;
  requesting_department: string;
  service_department: string;
  service_type: string;
  expected_duration: number; // in hours
  request_description: string;
  attached_files: string[]; // file URLs/paths
  status: 'submitted' | 'in_review' | 'approved' | 'in_progress' | 'completed' | 'rejected' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assigned_to?: string;
  submitted_by: string;
  submitted_at: string;
  updated_at: string;
  completed_at?: string;
  estimated_completion?: string;
  actual_completion?: string;
  sla_due_date: string;
  sla_status: 'on_track' | 'at_risk' | 'overdue' | 'completed_on_time' | 'completed_late';
}

// Service types with their expected durations (in hours)
const SERVICE_TYPES = {
  'Petty Cash': { duration: 48, department: 'Finance' },
  'Travel Authorization': { duration: 72, department: 'Finance' },
  'Purchase Request': { duration: 120, department: 'Procurement & Supply Chain' },
  'IT Support': { duration: 24, department: 'IT' },
  'Equipment Request': { duration: 168, department: 'Assets & Infrastructure' },
  'Leave Request': { duration: 48, department: 'Human Resources & Administration' },
  'Training Request': { duration: 120, department: 'Human Resources & Administration' },
  'Document Request': { duration: 24, department: 'Legal' },
  'Budget Approval': { duration: 72, department: 'Finance' },
  'Audit Request': { duration: 240, department: 'Audit' },
  'Communication Request': { duration: 48, department: 'Corporate Communications & External Affairs' },
  'Strategic Planning': { duration: 336, department: 'Corporate Planning' },
  'Executive Approval': { duration: 96, department: "MD's Secretariat" },
  'Terminal Access': { duration: 48, department: 'Terminal & Transmissions' },
  'Fuel Trading Authorization': { duration: 72, department: 'Fuel Trading' },
};

// GET /api/requests - Fetch all requests
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const department = searchParams.get('department');
    const submitted_by = searchParams.get('submitted_by');
    const assigned_to = searchParams.get('assigned_to');

    const connection = db.getConnection('main');
    if (!connection) {
      // Return mock requests if no database connection
      return NextResponse.json([
        {
          request_id: "REQ-001",
          requesting_department: "Human Resources & Administration",
          service_department: "Finance",
          service_type: "Petty Cash",
          expected_duration: 48,
          request_description: "Request for petty cash to purchase office supplies",
          attached_files: [],
          status: "in_progress",
          priority: "medium",
          assigned_to: "Lisa Chen",
          submitted_by: "John Doe",
          submitted_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          updated_at: new Date().toISOString(),
          sla_due_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          sla_status: "on_track"
        },
        {
          request_id: "REQ-002",
          requesting_department: "IT",
          service_department: "Procurement & Supply Chain",
          service_type: "Equipment Request",
          expected_duration: 168,
          request_description: "New laptops for development team",
          attached_files: ["spec_document.pdf"],
          status: "submitted",
          priority: "high",
          submitted_by: "Jane Smith",
          submitted_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          updated_at: new Date().toISOString(),
          sla_due_date: new Date(Date.now() + 166 * 60 * 60 * 1000).toISOString(),
          sla_status: "on_track"
        }
      ]);
    }

    let query = 'SELECT * FROM requests WHERE 1=1';
    const params: any[] = [];
    let paramIndex = 1;

    if (status) {
      query += ` AND status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (department) {
      query += ` AND (requesting_department = $${paramIndex} OR service_department = $${paramIndex})`;
      params.push(department);
      paramIndex++;
    }

    if (submitted_by) {
      query += ` AND submitted_by = $${paramIndex}`;
      params.push(submitted_by);
      paramIndex++;
    }

    if (assigned_to) {
      query += ` AND assigned_to = $${paramIndex}`;
      params.push(assigned_to);
      paramIndex++;
    }

    query += ' ORDER BY submitted_at DESC';

    const requests = await connection.query(query, params);
    return NextResponse.json(requests);
  } catch (error) {
    console.error('Error fetching requests:', error);
    return NextResponse.json(
      { error: 'Failed to fetch requests' },
      { status: 500 }
    );
  }
}

// POST /api/requests - Create new request
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      requesting_department,
      service_department,
      service_type,
      request_description,
      attached_files,
      submitted_by,
      priority
    } = body;

    // Validate required fields
    if (!requesting_department || !service_department || !service_type || !request_description || !submitted_by) {
      return NextResponse.json(
        { error: 'All required fields must be provided' },
        { status: 400 }
      );
    }

    const request_id = `REQ-${Date.now().toString().slice(-6)}`;
    const expected_duration = SERVICE_TYPES[service_type as keyof typeof SERVICE_TYPES]?.duration || 72;
    const submitted_at = new Date().toISOString();
    const sla_due_date = new Date(Date.now() + expected_duration * 60 * 60 * 1000).toISOString();

    const requestData = {
      request_id,
      requesting_department,
      service_department,
      service_type,
      expected_duration,
      request_description,
      attached_files: attached_files || [],
      status: 'submitted',
      priority: priority || 'medium',
      submitted_by,
      submitted_at,
      updated_at: submitted_at,
      sla_due_date,
      sla_status: 'on_track'
    };

    const connection = db.getConnection('main');
    if (!connection) {
      // Return success even without database for demo purposes
      return NextResponse.json(requestData, { status: 201 });
    }

    const result = await connection.query(`
      INSERT INTO requests (
        request_id, requesting_department, service_department, service_type,
        expected_duration, request_description, attached_files, status,
        priority, submitted_by, submitted_at, updated_at, sla_due_date, sla_status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
      RETURNING *
    `, [
      request_id,
      requesting_department,
      service_department,
      service_type,
      expected_duration,
      request_description,
      JSON.stringify(attached_files || []),
      'submitted',
      priority || 'medium',
      submitted_by,
      submitted_at,
      submitted_at,
      sla_due_date,
      'on_track'
    ]);

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error('Error creating request:', error);
    return NextResponse.json(
      { error: 'Failed to create request' },
      { status: 500 }
    );
  }
}

// PUT /api/requests - Update request status
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { request_id, status, assigned_to, comments, ...updates } = body;

    if (!request_id) {
      return NextResponse.json(
        { error: 'Request ID is required' },
        { status: 400 }
      );
    }

    const connection = db.getConnection('main');
    if (!connection) {
      return NextResponse.json({ success: true, updates });
    }

    // Calculate SLA status
    let sla_status = 'on_track';
    const now = new Date();

    // Get current request to check SLA due date
    const currentRequest = await connection.query(
      'SELECT sla_due_date FROM requests WHERE request_id = $1',
      [request_id]
    );

    if (currentRequest.length > 0) {
      const dueDate = new Date(currentRequest[0].sla_due_date);
      if (status === 'completed') {
        sla_status = now <= dueDate ? 'completed_on_time' : 'completed_late';
      } else if (now > dueDate) {
        sla_status = 'overdue';
      } else if (now > new Date(dueDate.getTime() - 24 * 60 * 60 * 1000)) {
        sla_status = 'at_risk';
      }
    }

    const updateFields = {
      ...updates,
      updated_at: new Date().toISOString(),
      sla_status
    };

    if (status) {
      updateFields.status = status;
      if (status === 'completed') {
        updateFields.completed_at = new Date().toISOString();
      }
    }

    if (assigned_to) {
      updateFields.assigned_to = assigned_to;
    }

    const setClause = Object.keys(updateFields)
      .map((key, index) => `${key} = $${index + 2}`)
      .join(', ');

    const result = await connection.query(`
      UPDATE requests
      SET ${setClause}
      WHERE request_id = $1
      RETURNING *
    `, [request_id, ...Object.values(updateFields)]);

    if (result.length === 0) {
      return NextResponse.json(
        { error: 'Request not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error('Error updating request:', error);
    return NextResponse.json(
      { error: 'Failed to update request' },
      { status: 500 }
    );
  }
}

// GET /api/requests/service-types - Get available service types
export async function GET_SERVICE_TYPES() {
  return NextResponse.json(SERVICE_TYPES);
}
