import { type NextRequest, NextResponse } from 'next/server';
import { db, type DatabaseConfig, initializeDatabase } from '@/lib/database';

// POST /api/database/connect - Establish database connection
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, host, port, database, username, password, ssl, connectionId } = body;

    // Validate required fields
    if (!type || !host || !port || !database || !username) {
      return NextResponse.json(
        { error: 'Missing required connection parameters' },
        { status: 400 }
      );
    }

    const config: DatabaseConfig = {
      type: type as DatabaseConfig['type'],
      host,
      port: Number.parseInt(port),
      database,
      username,
      password: password || '',
      ssl: ssl || false
    };

    const connId = connectionId || 'main';

    try {
      // Close existing connection if any
      await db.closeConnection(connId);

      // Create new connection
      const connection = await db.createConnection(connId, config);

      // Initialize database schema if this is the main connection
      if (connId === 'main') {
        await initializeDatabase(connection);
      }

      return NextResponse.json({
        success: true,
        message: `Successfully connected to ${config.type} database`,
        connectionId: connId,
        config: {
          ...config,
          password: '***' // Don't return the actual password
        }
      });
    } catch (connectionError) {
      return NextResponse.json(
        {
          success: false,
          error: connectionError instanceof Error ? connectionError.message : 'Failed to establish connection'
        },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('Database connect error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Connection failed'
      },
      { status: 500 }
    );
  }
}

// DELETE /api/database/connect - Close database connection
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const connectionId = searchParams.get('connectionId') || 'main';

    await db.closeConnection(connectionId);

    return NextResponse.json({
      success: true,
      message: `Connection ${connectionId} closed successfully`
    });
  } catch (error) {
    console.error('Database disconnect error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to close connection'
      },
      { status: 500 }
    );
  }
}

// GET /api/database/connect - Get connection status
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const connectionId = searchParams.get('connectionId') || 'main';

    const connection = db.getConnection(connectionId);

    return NextResponse.json({
      connected: connection ? connection.isConnected() : false,
      connectionId
    });
  } catch (error) {
    console.error('Database status error:', error);
    return NextResponse.json(
      {
        connected: false,
        error: error instanceof Error ? error.message : 'Failed to get connection status'
      },
      { status: 500 }
    );
  }
}
