import { type NextRequest, NextResponse } from 'next/server';
import { db, type DatabaseConfig } from '@/lib/database';

// POST /api/database/test - Test database connection
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, host, port, database, username, password, ssl } = body;

    // Validate required fields
    if (!type || !host || !port || !database || !username) {
      return NextResponse.json(
        { error: 'Missing required connection parameters' },
        { status: 400 }
      );
    }

    const config: DatabaseConfig = {
      type: type as DatabaseConfig['type'],
      host,
      port: Number.parseInt(port),
      database,
      username,
      password: password || '',
      ssl: ssl || false
    };

    // Test the connection
    const result = await db.testConnection(config);

    if (result.success) {
      return NextResponse.json({
        success: true,
        message: result.message,
        config: {
          ...config,
          password: '***' // Don't return the actual password
        }
      });
    } else {
      return NextResponse.json(
        {
          success: false,
          error: result.message
        },
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('Database test error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Connection test failed'
      },
      { status: 500 }
    );
  }
}
