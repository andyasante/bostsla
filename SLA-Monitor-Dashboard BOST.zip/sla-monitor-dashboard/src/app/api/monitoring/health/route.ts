import { type NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/database';

interface HealthCheck {
  service_id: string;
  endpoint: string;
  status: 'operational' | 'degraded' | 'outage' | 'maintenance';
  response_time: number;
  uptime: number;
  last_check: string;
  error_message?: string;
}

// GET /api/monitoring/health - Perform health checks on all services
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const service_id = searchParams.get('service_id');

    const connection = db.getConnection('main');
    let services: any[] = [];

    if (connection) {
      let query = 'SELECT * FROM services WHERE monitoring_enabled = true';
      const params: any[] = [];

      if (service_id) {
        query += ' AND service_id = $1';
        params.push(service_id);
      }

      services = await connection.query(query, params);
    } else {
      // Use default services if no database connection
      services = [
        {
          service_id: "srv-001",
          name: "BOST Employee Portal",
          endpoint: "https://portal.bost.gov.gh/health",
          monitoring_enabled: true
        },
        {
          service_id: "srv-002",
          name: "Financial Management System",
          endpoint: "https://finance.bost.gov.gh/api/health",
          monitoring_enabled: true
        }
      ];
    }

    const healthChecks: HealthCheck[] = [];

    // Perform health checks on each service
    for (const service of services) {
      const healthCheck = await performHealthCheck(service);
      healthChecks.push(healthCheck);

      // Update service status in database if connected
      if (connection) {
        try {
          await connection.query(`
            UPDATE services
            SET
              status = $1,
              response_time = $2,
              uptime = $3,
              updated_at = CURRENT_TIMESTAMP
            WHERE service_id = $4
          `, [
            healthCheck.status,
            `${healthCheck.response_time.toFixed(2)}s`,
            healthCheck.uptime,
            service.service_id
          ]);

          // Record metric
          await connection.query(`
            INSERT INTO metrics (service_id, metric_type, value, unit)
            VALUES ($1, $2, $3, $4)
          `, [
            service.service_id,
            'response_time',
            healthCheck.response_time,
            'seconds'
          ]);
        } catch (updateError) {
          console.error('Error updating service status:', updateError);
        }
      }
    }

    return NextResponse.json({
      timestamp: new Date().toISOString(),
      total_services: healthChecks.length,
      healthy_services: healthChecks.filter(hc => hc.status === 'operational').length,
      health_checks: healthChecks
    });
  } catch (error) {
    console.error('Error performing health checks:', error);
    return NextResponse.json(
      { error: 'Failed to perform health checks' },
      { status: 500 }
    );
  }
}

// POST /api/monitoring/health - Force health check for specific service
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { service_id, endpoint } = body;

    if (!service_id) {
      return NextResponse.json(
        { error: 'Service ID is required' },
        { status: 400 }
      );
    }

    const connection = db.getConnection('main');
    let service: any;

    if (connection) {
      const services = await connection.query(
        'SELECT * FROM services WHERE service_id = $1',
        [service_id]
      );

      if (services.length === 0) {
        return NextResponse.json(
          { error: 'Service not found' },
          { status: 404 }
        );
      }

      service = services[0];
    } else {
      service = {
        service_id,
        name: `Service ${service_id}`,
        endpoint: endpoint || `https://api.bost.gov.gh/${service_id}/health`
      };
    }

    const healthCheck = await performHealthCheck(service);

    // Update service status in database if connected
    if (connection) {
      await connection.query(`
        UPDATE services
        SET
          status = $1,
          response_time = $2,
          uptime = $3,
          updated_at = CURRENT_TIMESTAMP
        WHERE service_id = $4
      `, [
        healthCheck.status,
        `${healthCheck.response_time.toFixed(2)}s`,
        healthCheck.uptime,
        service.service_id
      ]);
    }

    return NextResponse.json(healthCheck);
  } catch (error) {
    console.error('Error performing health check:', error);
    return NextResponse.json(
      { error: 'Failed to perform health check' },
      { status: 500 }
    );
  }
}

// Helper function to perform actual health check
async function performHealthCheck(service: any): Promise<HealthCheck> {
  const startTime = Date.now();
  let status: 'operational' | 'degraded' | 'outage' | 'maintenance' = 'operational';
  let response_time = 0;
  let error_message: string | undefined;

  try {
    // If no endpoint, simulate health check
    if (!service.endpoint || service.endpoint === 'N/A' || !service.endpoint.startsWith('http')) {
      // Simulate response time and status
      response_time = 0.5 + Math.random() * 2; // 0.5 to 2.5 seconds

      // Simulate occasional issues
      const random = Math.random();
      if (random < 0.05) { // 5% chance of outage
        status = 'outage';
        error_message = 'Service unreachable';
        response_time = 0;
      } else if (random < 0.15) { // 10% chance of degraded performance
        status = 'degraded';
        response_time = 3 + Math.random() * 2; // 3-5 seconds
      }
    } else {
      // Perform actual HTTP health check
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

        const response = await fetch(service.endpoint, {
          method: 'GET',
          signal: controller.signal,
          headers: {
            'User-Agent': 'BOST-SLA-Monitor/1.0'
          }
        });

        clearTimeout(timeoutId);
        response_time = (Date.now() - startTime) / 1000;

        if (response.ok) {
          if (response_time > 5) {
            status = 'degraded';
          } else {
            status = 'operational';
          }
        } else {
          status = response.status >= 500 ? 'outage' : 'degraded';
          error_message = `HTTP ${response.status}: ${response.statusText}`;
        }
      } catch (fetchError) {
        response_time = (Date.now() - startTime) / 1000;
        if (fetchError instanceof Error) {
          if (fetchError.name === 'AbortError') {
            status = 'outage';
            error_message = 'Request timeout';
          } else {
            status = 'outage';
            error_message = `Network error: ${fetchError.message}`;
          }
        } else {
          status = 'outage';
          error_message = 'Unknown network error';
        }
      }
    }

    // Calculate uptime (simplified - in production this would be based on historical data)
    let uptime = 100.0;
    if (status === 'outage') {
      uptime = 92.0 + Math.random() * 5; // 92-97%
    } else if (status === 'degraded') {
      uptime = 97.0 + Math.random() * 2; // 97-99%
    } else {
      uptime = 99.0 + Math.random() * 1; // 99-100%
    }

    return {
      service_id: service.service_id,
      endpoint: service.endpoint || 'N/A',
      status,
      response_time,
      uptime,
      last_check: new Date().toISOString(),
      error_message
    };
  } catch (error) {
    return {
      service_id: service.service_id,
      endpoint: service.endpoint || 'N/A',
      status: 'outage',
      response_time: 0,
      uptime: 0,
      last_check: new Date().toISOString(),
      error_message: error instanceof Error ? error.message : 'Health check failed'
    };
  }
}
