import { type NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/database';

interface Alert {
  id?: number;
  alert_id: string;
  title: string;
  description: string;
  severity: 'critical' | 'warning' | 'info';
  department: string;
  status: 'active' | 'investigating' | 'scheduled' | 'monitoring' | 'resolved';
  service_id?: string;
  assignee: string;
  affected_services: string[];
}

// GET /api/alerts - Fetch all alerts
export async function GET(request: NextRequest) {
  try {
    const connection = db.getConnection('main');
    if (!connection) {
      // Return default alerts if no database connection
      return NextResponse.json([
        {
          alert_id: "alert-001",
          title: "Asset Management System Outage",
          description: "Asset Management System is completely unavailable. Database connection failed.",
          severity: "critical",
          department: "Assets & Infrastructure",
          status: "active",
          assignee: "John Smith",
          affected_services: ["Asset Management System", "Infrastructure Monitoring"],
          timestamp: "30 minutes ago"
        },
        {
          alert_id: "alert-002",
          title: "High Response Time - Terminal Operations",
          description: "Terminal Operations Management system response time exceeding 3 seconds consistently.",
          severity: "warning",
          department: "Terminal & Transmissions",
          status: "investigating",
          assignee: "Sarah Johnson",
          affected_services: ["Terminal Operations Management"],
          timestamp: "2 hours ago"
        },
        {
          alert_id: "alert-003",
          title: "Scheduled Maintenance - Procurement System",
          description: "Planned maintenance window for Procurement & Supply Chain System database upgrade.",
          severity: "info",
          department: "Procurement & Supply Chain",
          status: "scheduled",
          assignee: "Mike Wilson",
          affected_services: ["Procurement & Supply Chain System"],
          timestamp: "4 hours ago"
        }
      ]);
    }

    const alerts = await connection.query(`
      SELECT * FROM alerts
      WHERE status != 'resolved'
      ORDER BY
        CASE severity
          WHEN 'critical' THEN 1
          WHEN 'warning' THEN 2
          WHEN 'info' THEN 3
        END,
        created_at DESC
    `);

    return NextResponse.json(alerts);
  } catch (error) {
    console.error('Error fetching alerts:', error);
    return NextResponse.json(
      { error: 'Failed to fetch alerts' },
      { status: 500 }
    );
  }
}

// POST /api/alerts - Create new alert
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      title,
      description,
      severity,
      department,
      service_id,
      assignee,
      affected_services
    } = body;

    // Validate required fields
    if (!title || !description || !severity) {
      return NextResponse.json(
        { error: 'Title, description, and severity are required' },
        { status: 400 }
      );
    }

    const alert_id = `alert-${Date.now().toString().slice(-6)}`;

    const connection = db.getConnection('main');
    if (!connection) {
      // Return success even without database for demo purposes
      return NextResponse.json({
        alert_id,
        title,
        description,
        severity,
        department,
        status: 'active',
        service_id,
        assignee: assignee || 'Unassigned',
        affected_services: affected_services || [],
        created_at: new Date().toISOString()
      });
    }

    const result = await connection.query(`
      INSERT INTO alerts (
        alert_id, title, description, severity, department,
        status, service_id, assignee, affected_services
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *
    `, [
      alert_id,
      title,
      description,
      severity,
      department,
      'active',
      service_id,
      assignee || 'Unassigned',
      affected_services || []
    ]);

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error('Error creating alert:', error);
    return NextResponse.json(
      { error: 'Failed to create alert' },
      { status: 500 }
    );
  }
}

// PUT /api/alerts - Update alert (acknowledge, resolve, etc.)
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { alert_id, action, ...updates } = body;

    if (!alert_id) {
      return NextResponse.json(
        { error: 'Alert ID is required' },
        { status: 400 }
      );
    }

    const connection = db.getConnection('main');
    if (!connection) {
      return NextResponse.json({ success: true, action, updates });
    }

    let updateQuery = '';
    let queryParams: any[] = [alert_id];

    switch (action) {
      case 'acknowledge':
        updateQuery = `
          UPDATE alerts
          SET status = 'investigating', acknowledged_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
          WHERE alert_id = $1
          RETURNING *
        `;
        break;
      case 'resolve':
        updateQuery = `
          UPDATE alerts
          SET status = 'resolved', resolved_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
          WHERE alert_id = $1
          RETURNING *
        `;
        break;
      default:
        // General update
        const setClause = Object.keys(updates)
          .map((key, index) => `${key} = $${index + 2}`)
          .join(', ');

        updateQuery = `
          UPDATE alerts
          SET ${setClause}, updated_at = CURRENT_TIMESTAMP
          WHERE alert_id = $1
          RETURNING *
        `;
        queryParams = [alert_id, ...Object.values(updates)];
        break;
    }

    const result = await connection.query(updateQuery, queryParams);

    if (result.length === 0) {
      return NextResponse.json(
        { error: 'Alert not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error('Error updating alert:', error);
    return NextResponse.json(
      { error: 'Failed to update alert' },
      { status: 500 }
    );
  }
}

// DELETE /api/alerts - Delete alert
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const alert_id = searchParams.get('alert_id');

    if (!alert_id) {
      return NextResponse.json(
        { error: 'Alert ID is required' },
        { status: 400 }
      );
    }

    const connection = db.getConnection('main');
    if (!connection) {
      return NextResponse.json({ success: true });
    }

    const result = await connection.query(
      'DELETE FROM alerts WHERE alert_id = $1 RETURNING *',
      [alert_id]
    );

    if (result.length === 0) {
      return NextResponse.json(
        { error: 'Alert not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting alert:', error);
    return NextResponse.json(
      { error: 'Failed to delete alert' },
      { status: 500 }
    );
  }
}
