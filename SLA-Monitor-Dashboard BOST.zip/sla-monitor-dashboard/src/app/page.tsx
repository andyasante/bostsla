import { DashboardHeader } from "@/components/dashboard/dashboard-header";
import { KPICards } from "@/components/dashboard/kpi-cards";
import { ChartsSection } from "@/components/dashboard/charts-section";
import { ServiceStatusTable } from "@/components/dashboard/service-status-table";
import { AlertsPanel } from "@/components/dashboard/alerts-panel";
import { DataIntegrationPanel } from "@/components/dashboard/data-integration-panel";
import { UserInputForms } from "@/components/dashboard/user-input-forms";
import { AdvancedConnectors } from "@/components/dashboard/advanced-connectors";
import { RequestTracking } from "@/components/dashboard/request-tracking";
import { FilterProvider } from "@/components/dashboard/filter-context";
import { ServiceProvider } from "@/components/dashboard/service-context";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function DashboardPage() {
  return (
    <ServiceProvider>
      <FilterProvider>
        <div className="min-h-screen bg-gray-50/50">
          <DashboardHeader />

          <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Dashboard Overview</TabsTrigger>
            <TabsTrigger value="requests">Request Tracking</TabsTrigger>
            <TabsTrigger value="data-sources">Data Sources</TabsTrigger>
            <TabsTrigger value="user-input">User Input</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* KPI Overview */}
            <section>
              <h2 className="text-2xl font-bold tracking-tight mb-4">
                SLA Performance Overview
              </h2>
              <KPICards />
            </section>

            {/* Service Status and Alerts */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <h2 className="text-2xl font-bold tracking-tight mb-4">
                  Service Status
                </h2>
                <ServiceStatusTable />
              </div>

              <div>
                <h2 className="text-2xl font-bold tracking-tight mb-4">
                  Active Alerts
                </h2>
                <AlertsPanel />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="requests">
            <RequestTracking />
          </TabsContent>

          <TabsContent value="data-sources" className="space-y-8">
            <DataIntegrationPanel />
            <AdvancedConnectors />
          </TabsContent>

          <TabsContent value="user-input">
            <UserInputForms />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {/* Charts and Analytics */}
            <section>
              <h2 className="text-2xl font-bold tracking-tight mb-4">
                Performance Analytics
              </h2>
              <ChartsSection />
            </section>
          </TabsContent>
        </Tabs>
      </main>
        </div>
      </FilterProvider>
    </ServiceProvider>
  );
}
